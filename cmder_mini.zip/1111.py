# -- coding: utf-8 --

# ==============================================================================
#  THƯ VIỆN CẦN THIẾT
# ==============================================================================
import logging
import logging.handlers
import time
import random
import string
import json
import asyncio
import smtplib
from collections import Counter
from email.mime.text import MIMEText
from urllib.parse import quote
from datetime import datetime, timedelta, time as dt_time
from zoneinfo import ZoneInfo
import os
import re
from enum import Enum, auto
from tenacity import retry, stop_after_attempt, wait_exponential

import httpx
import aiofiles

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import (
    Application, CommandHandler, ContextTypes,
    CallbackQueryHandler, MessageHandler, filters
)
from telegram.error import Forbidden, BadRequest
from telegram.constants import ParseMode, ChatAction

# ==============================================================================
#  CẤU HÌNH BOT
# ==============================================================================
TELEGRAM_TOKEN = "8467903286:AAGlrKH_yC65BHHp0cotGZng06m0-y9h830"
API_PASSWORD = "Qx4lequockhang@@"
API_TOKEN = "053b8299c7b9b9c04ce6f1c5ecf6eed4"
BANK_ID = "VCB"
BANK_ACCOUNT_NUMBER = "1049565152"
ACCOUNT_NAME = "LE QUOC KHANG"
ADMIN_USER_ID = 7193749511
ADMIN_USERNAME = "dichcutelegram"
SUPPORT_GROUP_LINK = "https://t.me/dinotool"
ICLOUD_PACKAGE_PRICE = 35000
ENABLE_EMAIL_SENDING = True
SENDER_EMAIL = "lequockhang978@gmail.com"
SENDER_APP_PASSWORD = "tpihymuyjeqlkqhs"
GEMINI_API_KEY = "AIzaSyAoNa_Dg3ZbKE2xqVXt_XjYveOJzZVF6-c"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + GEMINI_API_KEY

# ==============================================================================
#  CÁC THIẾT LẬP HỆ THỐNG
# ==============================================================================
LINKS_FILE, HISTORY_FILE, PROCESSED_TX_FILE = "data_available_links.json", "data_order_history.json", "data_processed_ids.json"
USERS_FILE, BANNED_USERS_FILE, COUPONS_FILE = "data_users.json", "data_banned_users.json", "data_coupons.json"
PENDING_ORDERS_FILE = "data_pending_orders.json"
ORDER_EXPIRATION_SECONDS, BANK_CHECK_INTERVAL_SECONDS = 900, 65

# Tối ưu: Compile regex trước để tăng tốc
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
ORDER_CODE_REGEX = re.compile(r'^ICLD\d{6}$')
ORDER_CODE_SEARCH_REGEX = re.compile(r'ICLD\d{6}')

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

available_links, pending_orders, processed_transaction_ids = set(), {}, set()
order_history, user_data_db, banned_users, coupons = [], {}, set(), {}
file_lock = asyncio.Lock()
# Tối ưu: HTTP connection pooling với limits
http_client = httpx.AsyncClient(
    timeout=httpx.Timeout(15.0, connect=5.0),  # Giảm timeout để phản hồi nhanh hơn
    limits=httpx.Limits(max_keepalive_connections=10, max_connections=20)  # Pool connections
    # http2=True bị tắt vì chưa cài h2, vẫn nhanh với connection pooling
)

# Cache để giảm database reads
_cache = {
    "last_save_time": 0,
    "save_debounce": 2.0,  # Chỉ save sau 2 giây không có thay đổi
    "pending_save": False
}

class OrderStatus(Enum):
    COMPLETED = "✅ Hoàn thành"
    COMPLETED_RESENT = "✅ Hoàn thành (Gửi lại)"
    PENDING_LINK = "⏳ Chờ link"

def status_text(s):
    return s.value if isinstance(s, OrderStatus) else str(s or "")

# ==============================================================================
#  ENUM VÀ CÁC LOẠI TICKET
# ==============================================================================
class TicketType(Enum):
    LINK_NOT_WORKING = auto()
    EMAIL_NOT_FOUND = auto()
    HOW_TO_USE_ICLOUD = auto()
    BILLING_QUESTIONS = auto()
    PRIVACY_CONCERNS = auto()
    FAMILY_SHARING = auto()
    OTHER = auto()

# ==============================================================================
#  CÁC HÀM LIÊN QUAN ĐẾN AI & HỖ TRỢ TỰ ĐỘNG
# ==============================================================================
async def ask_gemini(question: str) -> str:
    if not GEMINI_API_KEY: return "Tính năng AI hiện chưa được cấu hình."
    headers = {'Content-Type': 'application/json'}
    prompt = f"""
    BẠN LÀ "DINO ICLOUD", MỘT TRỢ LÝ AI CHUYÊN GIA VỀ ICLOUD.
    **VAI TRÒ & TÍNH CÁCH CỦA BẠN:**
    1.  **Tên của bạn:** Dino iCloud, hoặc có thể xưng là "Dino".
    2.  **Chuyên môn:** Bạn là chuyên gia hàng đầu về MỌI THỨ liên quan đến iCloud và các dịch vụ Apple.
    3.  **Tính cách:** Thân thiện, chuyên nghiệp, đáng tin cậy.
    4.  **Môi trường:** Bạn đang hoạt động trong một bot Telegram chuyên bán và hỗ trợ gói iCloud 2TB.
    **QUY TẮC BẮT BUỘC KHI TRẢ LỜI:**
    - **Tập trung tuyệt đối:** Chỉ trả lời các câu hỏi liên quan đến iCloud và Apple. Nếu người dùng hỏi về chủ đề khác, hãy lịch sự trả lời: "Dino chỉ là chuyên gia về iCloud thôi, rất tiếc mình không thể trả lời câu hỏi này. Bạn có cần Dino giúp gì về iCloud không?"
    - **Giọng văn rõ ràng:** Sử dụng ngôn ngữ đơn giản, dễ hiểu.
    - **Không bán hàng lộ liễu:** Bạn có thể đề cập đến lợi ích của dung lượng lớn nhưng không mời chào mua hàng trực tiếp.
    - **Luôn xưng tên:** Bắt đầu câu trả lời bằng "Chào bạn, Dino đây!" hoặc một câu tương tự.
    ---
    **YÊU CẦU TỪ NGƯỜI DÙNG:**
    Dựa vào vai trò và các quy tắc trên, hãy trả lời câu hỏi sau của người dùng: "{question}"
    """
    payload = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        response = await http_client.post(GEMINI_API_URL, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        data = response.json()
        if 'candidates' not in data or not data['candidates']:
              logger.warning(f"Gemini API response không hợp lệ: {data}")
              return "Trợ lý AI không thể đưa ra câu trả lời lúc này."
        return data['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        logger.error(f"Lỗi khi gọi Gemini API: {e}")
        return "Trợ lý AI hiện đang gặp sự cố. Vui lòng liên hệ Admin."

async def validate_activation_link(link: str) -> bool:
    """Kiểm tra tính hợp lệ của link kích hoạt"""
    # Thêm logic kiểm tra link, ví dụ:
    if not link or not link.startswith('https://'):
        return False
    return True

async def send_activation_email_async(email: str, subject: str, full_name: str, link: str) -> bool:
    """Gửi email kích hoạt với async"""
    try:
        result, _ = send_activation_email(email, subject, full_name, link)
        return result
    except Exception as e:
        logger.error(f"Lỗi gửi email: {e}")
        return False

async def intelligent_ticket_classifier(query: str, user_id: int) -> dict:
    """
    AI-powered ticket classification và auto-resolution
    Returns: {"type": TicketType, "confidence": float, "auto_resolved": bool, "response": str, "action": str}
    """
    query_lower = query.lower()
    
    # Patterns for each ticket type với confidence scoring
    patterns = {
        TicketType.LINK_NOT_WORKING: {
            "keywords": ["link không hoạt động", "link lỗi", "link hỏng", "không vào được link", "link die", "link not work", "link bị lỗi"],
            "confidence_boost": 0.9
        },
        TicketType.EMAIL_NOT_FOUND: {
            "keywords": ["không nhận được mail", "chưa nhận mail", "kiểm tra mail", "email chưa tới", "không có email", "chưa có mail"],
            "confidence_boost": 0.85
        },
        TicketType.HOW_TO_USE_ICLOUD: {
            "keywords": ["cách sử dụng", "hướng dẫn", "how to", "làm sao", "cài đặt", "kích hoạt", "sử dụng icloud", "dùng icloud"],
            "confidence_boost": 0.8
        },
        TicketType.BILLING_QUESTIONS: {
            "keywords": ["thanh toán", "tiền", "giá", "phí", "billing", "cost", "chuyển khoản", "bank", "hoàn tiền", "refund"],
            "confidence_boost": 0.85
        },
        TicketType.PRIVACY_CONCERNS: {
            "keywords": ["riêng tư", "bảo mật", "thấy ảnh", "xem dữ liệu", "privacy", "private", "an toàn"],
            "confidence_boost": 0.9
        },
        TicketType.FAMILY_SHARING: {
            "keywords": ["rời nhóm", "tự thoát", "family sharing", "gia đình", "leave family", "out group"],
            "confidence_boost": 0.9
        }
    }
    
    # Calculate confidence for each type
    best_match = {"type": TicketType.OTHER, "confidence": 0.0}
    
    for ticket_type, pattern in patterns.items():
        confidence = 0.0
        keyword_matches = sum(1 for keyword in pattern["keywords"] if keyword in query_lower)
        
        if keyword_matches > 0:
            confidence = (keyword_matches / len(pattern["keywords"])) * pattern["confidence_boost"]
            
        if confidence > best_match["confidence"]:
            best_match = {"type": ticket_type, "confidence": confidence}
    
    # Auto-resolve nếu confidence >= 0.3
    if best_match["confidence"] >= 0.3:
        auto_response = await auto_resolve_ticket(best_match["type"], query, user_id)
        if auto_response:
            return {
                **best_match,
                "auto_resolved": True,
                "response": auto_response["message"],
                "action": auto_response["action"]
            }
    
    return {**best_match, "auto_resolved": False, "response": None, "action": "escalate_to_admin"}

async def auto_resolve_ticket(ticket_type: TicketType, query: str, user_id: int) -> dict | None:
    """Auto-resolve ticket dựa trên type"""
    
    if ticket_type == TicketType.LINK_NOT_WORKING:
        return await handle_link_not_working(user_id)
    
    elif ticket_type == TicketType.EMAIL_NOT_FOUND:
        return handle_email_not_found()
    
    elif ticket_type == TicketType.HOW_TO_USE_ICLOUD:
        return handle_icloud_tutorial()
    
    elif ticket_type == TicketType.BILLING_QUESTIONS:
        return handle_billing_questions(query)
    
    elif ticket_type == TicketType.PRIVACY_CONCERNS:
        return handle_privacy_concerns()
    
    elif ticket_type == TicketType.FAMILY_SHARING:
        return handle_family_sharing()
    
    return None

async def handle_link_not_working(user_id: int) -> dict:
    """Auto-resolve: Link not working → auto resend"""
    # Tìm đơn hàng gần nhất của user
    user_orders = [o for o in reversed(order_history) if o.get("user_id") == user_id and "Hoàn thành" in status_text(o.get("status"))]
    
    if user_orders:
        latest_order = user_orders[0]
        email = latest_order.get("email")
        order_code = latest_order.get("order_code")
        
        if available_links:
            new_link = list(available_links)[0]
            
            # Gửi lại email
            try:
                # Kiểm tra link trước khi gửi
                if not await validate_activation_link(new_link):
                    logger.warning(f"Link không hợp lệ: {new_link}")
                    # Bỏ qua link không hợp lệ
                    available_links.remove(new_link)
                    return None

                # Gửi email với link mới
                await send_activation_email_async(
                    email, f"[Auto-Support] Link kích hoạt mới - {order_code}", 
                    latest_order.get("full_name", "bạn"), new_link
                )
                
                # Update order history
                latest_order.update({'link': new_link, 'status': OrderStatus.COMPLETED_RESENT.value})
                await save_data()
                
                return {
                    "message": (
                        f"🤖 <b>ĐÃ TỰ ĐỘNG XỬ LÝ!</b>\n\n"
                        f"✅ Đã gửi lại link kích hoạt mới đến email <b>{email}</b>\n\n"
                        f"📧 Vui lòng kiểm tra hộp thư (kể cả thư mục spam)\n"
                        f"⏱️ Link mới sẽ có trong vòng 2-3 phút\n\n"
                        f"💡 <b>Nếu vẫn gặp vấn đề:</b> Vui lòng liên hệ Admin để được hỗ trợ thủ công."
                    ),
                    "action": "auto_resend_link"
                }
            except Exception as e:
                logger.error(f"Lỗi auto-resend link: {e}")
                return None
        else:
            return {
                "message": (
                    f"🤖 <b>ĐÃ PHÁT HIỆN VẤN ĐỀ!</b>\n\n"
                    f"❌ Hệ thống hiện đang tạm hết link thay thế\n"
                    f"📞 Đã tự động thông báo Admin để bổ sung link\n"
                    f"⏱️ Admin sẽ xử lý trong vòng 30 phút\n\n"
                    f"🎁 <b>Bồi thường:</b> Bạn sẽ được ưu tiên và nhận thêm 1 tháng miễn phí"
                ),
                "action": "auto_escalate_no_links"
            }
    else:
        return {
            "message": (
                f"🤖 <b>CẦN THÊM THÔNG TIN!</b>\n\n"
                f"❓ Không tìm thấy đơn hàng của bạn trong hệ thống\n"
                f"📝 Vui lòng cung cấp <b>mã đơn hàng</b> (VD: ICLD123456) để được hỗ trợ nhanh chóng\n\n"
                f"💬 Hoặc liên hệ Admin với thông tin:\n"
                f"• Email đã dùng để mua\n"
                f"• Thời gian mua gần đúng"
            ),
            "action": "request_order_info"
        }

def handle_email_not_found() -> dict:
    """Auto-resolve: Can't find email → spam check guide"""
    return {
        "message": (
            f"🤖 <b>HƯỚNG DẪN TÌM EMAIL KÍCH HOẠT</b>\n\n"
            f"📧 <b>Bước 1:</b> Kiểm tra hộp thư đến chính\n"
            f"🗑️ <b>Bước 2:</b> Kiểm tra thư mục <b>Spam/Thư rác</b>\n"
            f"📁 <b>Bước 3:</b> Kiểm tra các thư mục khác: Promotions, Social\n"
            f"🔍 <b>Bước 4:</b> Tìm kiếm với từ khóa <code>DinoTools</code> hoặc <code>iCloud</code>\n\n"
            f"📱 <b>Trên Gmail Mobile:</b>\n"
            f"• Mở Gmail → Chạm 3 gạch ngang → Spam\n"
            f"• Nếu tìm thấy → Đánh dấu 'Không phải spam'\n\n"
            f"⏱️ <b>Email thường đến trong vòng 1-5 phút sau thanh toán</b>\n\n"
            f"❌ <b>Nếu vẫn không tìm thấy:</b> Bấm nút bên dưới để được hỗ trợ"
        ),
        "action": "spam_check_guide"
    }

def handle_icloud_tutorial() -> dict:
    """Auto-resolve: How to use iCloud → interactive tutorial"""
    return {
        "message": (
            f"🤖 <b>HƯỚNG DẪN SỬ DỤNG ICLOUD 2TB</b>\n\n"
            f"📱 <b>BƯỚC 1: KÍCH HOẠT (SAU KHI NHẬN EMAIL)</b>\n"
            f"• Bấm vào link trong email\n"
            f"• Chọn <b>'Accept'</b> hoặc <b>'Chấp nhận'</b>\n"
            f"• Đăng nhập Apple ID của bạn\n\n"
            f"📊 <b>BƯỚC 2: KIỂM TRA DUNG LƯỢNG</b>\n"
            f"• iPhone: Cài đặt → Tên của bạn → iCloud\n"
            f"• Mac: Apple Menu → System Settings → Apple ID → iCloud\n"
            f"• Sẽ hiển thị <b>2TB available</b>\n\n"
            f"☁️ <b>BƯỚC 3: BẬT ĐỒNG BỘ</b>\n"
            f"• Photos (Ảnh)\n"
            f"• iCloud Drive\n"
            f"• Backup\n"
            f"• Contacts, Calendar, Notes\n\n"
            f"💡 <b>MẸO HAY:</b>\n"
            f"• Bật 'Optimize iPhone Storage' để tiết kiệm bộ nhớ\n"
            f"• Thiết lập Auto Backup hàng đêm\n"
            f"• Chia sẻ folder với gia đình qua iCloud Drive"
        ),
        "action": "icloud_tutorial"
    }

def handle_billing_questions(query: str) -> dict:
    """Auto-resolve: Billing questions → smart FAQ"""
    query_lower = query.lower()
    
    if any(word in query_lower for word in ["giá", "cost", "price", "bao nhiêu"]):
        message = (
            f"🤖 <b>THÔNG TIN GIÁ CẢ</b>\n\n"
            f"💰 <b>Gói iCloud 2TB:</b> {ICLOUD_PACKAGE_PRICE:,} VNĐ\n"
            f"⏱️ <b>Thời gian:</b> Vĩnh viễn (không hết hạn)\n"
            f"🎯 <b>So sánh Apple chính hãng:</b>\n"
            f"• Apple: 70,000 VNĐ/tháng = 840,000 VNĐ/năm\n"
            f"• DinoTools: {ICLOUD_PACKAGE_PRICE:,} VNĐ một lần\n"
            f"• <b>Tiết kiệm: {840000 - ICLOUD_PACKAGE_PRICE:,} VNĐ/năm</b>\n\n"
            f"🎁 <b>Ưu đãi hiện tại:</b>\n"
            f"• Miễn phí setup\n"
            f"• Bảo hành 20 ngày\n"
            f"• Hỗ trợ 24/7"
        )
    elif any(word in query_lower for word in ["hoàn tiền", "refund", "trả lại"]):
        message = (
            f"🤖 <b>CHÍNH SÁCH HOÀN TIỀN</b>\n\n"
            f"✅ <b>Điều kiện hoàn tiền:</b>\n"
            f"• Trong vòng 20 ngày từ khi mua\n"
            f"• Lỗi từ phía chúng tôi\n"
            f"• Link không hoạt động sau nhiều lần khắc phục\n\n"
            f"❌ <b>Không hoàn tiền nếu:</b>\n"
            f"• Tự ý rời khỏi Family Sharing\n"
            f"• Apple ID bị khóa/vô hiệu hóa\n"
            f"• Đã sử dụng thành công > 20 ngày\n\n"
            f"📝 <b>Quy trình hoàn tiền:</b>\n"
            f"1. Liên hệ Admin với mã đơn hàng\n"
            f"2. Admin kiểm tra và xác nhận\n"
            f"3. Hoàn tiền trong 1-3 ngày làm việc"
        )
    elif any(word in query_lower for word in ["chuyển khoản", "thanh toán", "payment"]):
        message = (
            f"🤖 <b>HƯỚNG DẪN THANH TOÁN</b>\n\n"
            f"🏦 <b>Phương thức hiện tại:</b>\n"
            f"• Chuyển khoản ngân hàng (VCB)\n"
            f"• Quét mã QR (nhanh nhất)\n\n"
            f"⚡ <b>Quy trình:</b>\n"
            f"1. Chọn 'Mua gói iCloud'\n"
            f"2. Nhập email nhận link\n"
            f"3. Quét QR hoặc chuyển khoản thủ công\n"
            f"4. Bấm 'Đã chuyển khoản'\n"
            f"5. Nhận link qua email trong 1-3 phút\n\n"
            f"💡 <b>Lưu ý quan trọng:</b>\n"
            f"• Chuyển đúng số tiền và nội dung\n"
            f"• Đơn hàng tự hủy sau 15 phút nếu không thanh toán"
        )
    else:
        message = (
            f"🤖 <b>HỖ TRỢ BILLING TỔNG QUÁT</b>\n\n"
            f"💰 <b>Giá:</b> {ICLOUD_PACKAGE_PRICE:,} VNĐ một lần, vĩnh viễn\n"
            f"💳 <b>Thanh toán:</b> Chuyển khoản VCB hoặc QR\n"
            f"🔄 <b>Hoàn tiền:</b> Trong 20 ngày nếu lỗi từ chúng tôi\n"
            f"📞 <b>Hỗ trợ:</b> 24/7 qua bot và admin\n\n"
            f"❓ <b>Câu hỏi cụ thể khác?</b>\n"
            f"Hãy mô tả chi tiết vấn đề của bạn để được hỗ trợ tốt nhất!"
        )
    
    return {"message": message, "action": "billing_faq"}

def handle_privacy_concerns() -> dict:
    """Auto-resolve: Privacy concerns"""
    return {
        "message": (
            f"🤖 <b>BẢO MẬT & QUYỀN RIÊNG TƯ</b>\n\n"
            f"🔐 <b>Apple Family Sharing hoàn toàn riêng tư:</b>\n"
            f"• Chỉ chia sẻ dung lượng lưu trữ\n"
            f"• KHÔNG chia sẻ nội dung, ảnh, tệp\n"
            f"• KHÔNG ai có thể xem dữ liệu của bạn\n"
            f"• Mỗi thành viên có iCloud riêng biệt\n\n"
            f"🛡️ <b>Bảo mật Apple:</b>\n"
            f"• End-to-end encryption\n"
            f"• Two-factor authentication\n"
            f"• Zero-knowledge architecture\n"
            f"• Tuân thủ GDPR và các chuẩn bảo mật quốc tế\n\n"
            f"✅ <b>Điều chúng tôi có thể thấy:</b>\n"
            f"• Email bạn đăng ký\n"
            f"• Thống kê dung lượng sử dụng\n"
            f"• Trạng thái kích hoạt\n\n"
            f"❌ <b>Điều chúng tôi KHÔNG thể thấy:</b>\n"
            f"• Ảnh, video, tài liệu của bạn\n"
            f"• Contacts, lịch, ghi chú\n"
            f"• Mật khẩu, thông tin cá nhân\n"
            f"• Vị trí hoặc hoạt động của bạn"
        ),
        "action": "privacy_explanation"
    }

def handle_family_sharing() -> dict:
    """Auto-resolve: Family sharing issues"""
    return {
        "message": (
            f"🤖 <b>FAMILY SHARING - HƯỚNG DẪN QUAN TRỌNG</b>\n\n"
            f"⚠️ <b>CẢNH BÁO:</b> KHÔNG TỰ Ý THOÁT KHỎI NHÓM!\n\n"
            f"❌ <b>Nếu bạn rời Family Sharing:</b>\n"
            f"• Dung lượng 2TB sẽ mất ngay lập tức\n"
            f"• Trở về 5GB miễn phí của Apple\n"
            f"• Dữ liệu không mất nhưng không sync được\n"
            f"• Phải mua lại để tiếp tục sử dụng\n\n"
            f"✅ <b>Cách sử dụng an toàn:</b>\n"
            f"• Chỉ sử dụng, KHÔNG tùy chỉnh cài đặt Family\n"
            f"• KHÔNG mời thêm người vào nhóm\n"
            f"• KHÔNG thay đổi payment method\n"
            f"• KHÔNG rời khỏi nhóm vì bất kỳ lý do gì\n\n"
            f"🆘 <b>Nếu đã thoát nhầm:</b>\n"
            f"• Liên hệ Admin ngay lập tức\n"
            f"• Cung cấp email và mã đơn hàng\n"
            f"• Admin sẽ mời lại (nếu còn slot)\n"
            f"• Có thể mất phí tái kích hoạt\n\n"
            f"💡 <b>Lưu ý:</b> Family Sharing chỉ là cách Apple chia sẻ dung lượng, hoàn toàn an toàn!"
        ),
        "action": "family_sharing_guide"
    }

def automated_support_handler(query: str) -> str | None:
    query_lower = query.lower()
    knowledge_base = {
        ("không nhận được mail", "chưa nhận mail", "kiểm tra mail"):
            "Chào bạn, link kích hoạt được gửi ngay sau khi thanh toán thành công. Vui lòng kiểm tra kỹ hộp thư đến, và cả thư mục **Spam (Thư rác)** nhé. Nếu vẫn không thấy, bạn có thể dùng chức năng 'Báo lỗi' để được hỗ trợ.",
        ("riêng tư", "thấy ảnh", "xem dữ liệu"):
            "Chào bạn, việc nâng cấp dung lượng qua Family Sharing **hoàn toàn riêng tư**. Không ai trong 'gia đình', kể cả chủ sở hữu, có thể xem được ảnh, tệp, hay bất kỳ dữ liệu nào của bạn. Mọi thứ được Apple bảo mật tuyệt đối.",
        ("rời nhóm", "tự thoát"):
            "Nếu bạn tự ý rời khỏi Nhóm gia đình (Family Sharing), dung lượng iCloud của bạn sẽ ngay lập tức trở về 5GB miễn phí. Dữ liệu của bạn sẽ không bị mất nhưng bạn sẽ không thể tải lên tệp mới cho đến khi mua lại dung lượng.",
        ("thanh toán", "chuyển khoản", "chuyển sai"):
            "Hệ thống sẽ tự động xác nhận thanh toán nếu bạn chuyển khoản **đúng số tiền và đúng nội dung**. Nếu bạn chuyển sai, vui lòng tạo một phiếu hỗ trợ để Admin kiểm tra thủ công nhé."
    }
    for keywords, answer in knowledge_base.items():
        if any(keyword in query_lower for keyword in keywords):
            return answer
    return None

# ==============================================================================
#  QUẢN LÝ DỮ LIỆU, GIAO DIỆN & CÁC HÀM CỐT LÕI
# ==============================================================================
async def save_data(force=False):
    """Tối ưu: Debounced save để giảm I/O"""
    global _cache
    current_time = time.time()
    
    # Nếu không force và chưa đến lúc save
    if not force and (current_time - _cache["last_save_time"]) < _cache["save_debounce"]:
        _cache["pending_save"] = True
        return
    
    async with file_lock:
        try:
            # Tối ưu: Sử dụng separators để giảm kích thước file
            def json_dumps_optimized(data):
                return json.dumps(data, separators=(',', ':'), ensure_ascii=False)
            
            async def write_json_async(file_path, data):
                async with aiofiles.open(file_path, 'w', encoding='utf-8') as f:
                    await f.write(json_dumps_optimized(data))
            
            global order_history, processed_transaction_ids
            
            # Lọc và giữ lại các đơn hàng trong vòng 60 ngày
            current_time = time.time()
            order_history = [
                order for order in order_history 
                if current_time - order.get('timestamp', 0) <= 60 * 24 * 60 * 60  # 60 ngày
            ]
            
            # Giới hạn số lượng transaction ID để tránh chiếm quá nhiều bộ nhớ
            processed_transaction_ids = set(list(processed_transaction_ids)[-10000:])
            
            files_to_save = [
                (LINKS_FILE, list(available_links)), 
                (HISTORY_FILE, order_history), 
                (PROCESSED_TX_FILE, list(processed_transaction_ids)), 
                (USERS_FILE, user_data_db), 
                (BANNED_USERS_FILE, list(banned_users)), 
                (COUPONS_FILE, coupons), 
                (PENDING_ORDERS_FILE, pending_orders)
            ]
            
            # Tối ưu: Parallel writes
            await asyncio.gather(*[write_json_async(fp, d) for fp, d in files_to_save])
            
            _cache["last_save_time"] = current_time
            _cache["pending_save"] = False
            
            logger.info(f"💾 Đã lưu dữ liệu. Đơn hàng: {len(order_history)}")
        except Exception as e:
            logger.error(f"❌ Lỗi khi lưu dữ liệu: {e}", exc_info=True)

async def save_data_debounced():
    """Background task để save dữ liệu pending"""
    while True:
        await asyncio.sleep(_cache["save_debounce"])
        if _cache["pending_save"]:
            await save_data(force=True)

def load_json_file(file_path, default_value):
    try:
        with open(file_path, 'r', encoding='utf-8') as f: return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        logger.warning(f"File {file_path} không hợp lệ hoặc không tồn tại, tạo file mới.")
        with open(file_path, 'w', encoding='utf-8') as f: json.dump(default_value, f, indent=4, ensure_ascii=False)
        return default_value

def load_data():
    global available_links, order_history, processed_transaction_ids, user_data_db, banned_users, coupons, pending_orders
    available_links, order_history, processed_transaction_ids = set(load_json_file(LINKS_FILE, [])), load_json_file(HISTORY_FILE, []), set(load_json_file(PROCESSED_TX_FILE, []))
    user_data_db, banned_users, coupons, pending_orders = load_json_file(USERS_FILE, {}), set(load_json_file(BANNED_USERS_FILE, [])), load_json_file(COUPONS_FILE, {}), load_json_file(PENDING_ORDERS_FILE, {})
    logger.info("📂 Đã tải dữ liệu từ các file JSON thành công.")

MAIN_MENU_TEXT = "Chào mừng bạn đến với <b>DinoTools - Bot Bán Gói iCloud 2TB</b> 🦖\n\nDung lượng khủng, giá siêu rẻ, kích hoạt trong một nốt nhạc!\n\n👇 Hãy chọn một chức năng bên dưới để bắt đầu nhé:"
HUONGDAN_TEXT = "✅ <b>HƯỚNG DẪN KÍCH HOẠT GÓI iCLOUD 2TB</b>\n\n<i>Sau khi nhận được link qua email, bạn chỉ cần bấm vào link và chấp nhận lời mời là xong!</i>\n\n<b>Để kiểm tra dung lượng:</b>\n1️⃣ Mở <b>Cài đặt</b> trên iPhone/iPad/Mac.\n2️⃣ Nhấn vào <b>Tên/Apple ID</b> của bạn ở trên cùng.\n3️⃣ Chọn mục <b>iCloud</b>. Bạn sẽ thấy dung lượng đã được nâng lên 2TB."
CHINHSACH_TEXT = f"💎 <b>CHÍNH SÁCH & BẢO HÀNH</b> 💎\n\n<b>Giá gói:</b> Chỉ <b>{ICLOUD_PACKAGE_PRICE:,} VNĐ</b>.\n\n✅ <b>Bảo hành:</b>\n• Hỗ trợ các vấn đề kỹ thuật trong suốt quá trình bạn sử dụng.\n• Bảo hành 1 đổi 1 hoặc hoàn tiền trong 20 ngày đầu nếu lỗi đến từ phía chúng tôi.\n\n❌ <b>Từ chối bảo hành nếu:</b>\n• Bạn tự ý rời khỏi Nhóm gia đình (Family Sharing).\n• Tài khoản Apple ID của bạn gặp vấn đề không liên quan đến chúng tôi."

def create_main_menu():
    keyboard = [
        [InlineKeyboardButton(f"🛒 Mua Gói iCloud 2TB ({ICLOUD_PACKAGE_PRICE:,} VNĐ)", callback_data='muahang_start')],
        [InlineKeyboardButton("📖 Hướng Dẫn", callback_data='huongdan'), InlineKeyboardButton("📜 Chính Sách", callback_data='chinhsach')],
        [InlineKeyboardButton("👨‍💻 Hỗ trợ & Hỏi đáp", callback_data='lienhe_admin'), InlineKeyboardButton("💬 Nhóm Cộng đồng", url=SUPPORT_GROUP_LINK)],
        [InlineKeyboardButton("🧾 Lịch Sử Đơn Hàng", callback_data='lichsu_entry')]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_back_button_menu(text="⬅️ Quay Lại Menu Chính", callback="back_to_main"): return InlineKeyboardMarkup([[InlineKeyboardButton(text, callback_data=callback)]])
def create_success_menu(): return InlineKeyboardMarkup([ [InlineKeyboardButton("❗️ Cần hỗ trợ / Báo lỗi đơn hàng", callback_data='report_error')], [InlineKeyboardButton("⬅️ Quay Lại Menu Chính", callback_data='back_to_main')] ])

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
def send_activation_email(recipient_email: str, subject: str, full_name: str, activation_link: str):
    if not ENABLE_EMAIL_SENDING:
        logger.info("📧 Tính năng gửi email đang tắt.")
        return False, "Disabled by config"
    html_body = f'<html><head><style>body{{font-family:Arial,sans-serif;line-height:1.6;color:#333}}.container{{max-width:600px;margin:20px auto;padding:20px;border:1px solid #ddd;border-radius:10px}}.button{{display:inline-block;background-color:#007aff;color:white!important;padding:15px 25px;text-align:center;text-decoration:none;border-radius:8px;font-size:18px;font-weight:700;margin:20px 0}}h2{{color:#0056b3}}hr{{border:0;border-top:1px solid #eee;margin:20px 0}}</style></head><body><div class="container"><h2>🎉 Chúc Mừng Bạn Đã Đăng Ký Thành Công Gói iCloud 2TB!</h2><p>Xin chào <b>{full_name}</b>,</p><p>Cảm ơn bạn đã tin tưởng và sử dụng dịch vụ của me. Link kích hoạt gói dung lượng của bạn đã sẵn sàng.</p><p style="text-align:center">Vui lòng nhấp vào nút bên dưới để kích hoạt ngay lập tức:</p><p style="text-align:center"><a href="{activation_link}" class="button">KÍCH HOẠT NGAY</a></p><hr><p>Nếu có bất kỳ câu hỏi nào, vui lòng liên hệ admin qua Telegram hoặc tham gia nhóm hỗ trợ của chúng tôi.</p><p>Trân trọng,<b>Bot</b></p></div></body></html>'
    msg = MIMEText(html_body, 'html', 'utf-8')
    msg['Subject'], msg['From'], msg['To'] = subject, f"DinoTools iCloud Store <{SENDER_EMAIL}>", recipient_email
    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
            smtp_server.login(SENDER_EMAIL, SENDER_APP_PASSWORD)
            smtp_server.sendmail(SENDER_EMAIL, recipient_email, msg.as_string())
        logger.info(f"✅ Đã gửi email thành công đến {recipient_email}")
        return True, "Success"
    except Exception as e:
        logger.error(f"❌ Lỗi không xác định khi gửi email đến {recipient_email}: {e}")
        raise

async def generate_payment_qr(update: Update, context: ContextTypes.DEFAULT_TYPE, email: str, coupon_code: str = None):
    user = update.effective_user
    final_price = ICLOUD_PACKAGE_PRICE
    coupon_applied_text = ""
    
    # Tối ưu: Sử dụng compiled regex
    if not email or not EMAIL_REGEX.match(email):
        await context.bot.send_message(user.id, "❌ Email không hợp lệ. Vui lòng nhập lại hoặc bắt đầu lại bằng /start")
        return

    # Xử lý coupon với nhiều kiểm tra
    try:
        if coupon_code:
            coupon_details = coupons.get(coupon_code.upper())
            if coupon_details:
                # Kiểm tra hạn sử dụng coupon
                try:
                    is_expired = datetime.now() > datetime.strptime(
                        coupon_details.get('expires', '01-01-1970'), 
                        '%d-%m-%Y'
                    ).replace(hour=23, minute=59, second=59)
                except (ValueError, TypeError):
                    is_expired = True

                # Kiểm tra số lượng sử dụng
                is_used_up = (
                    isinstance(coupon_details.get('quantity'), int) and 
                    coupon_details.get('used', 0) >= coupon_details.get('quantity')
                )

                if is_used_up or is_expired:
                    await context.bot.send_message(
                        user.id, 
                        f"🎟️ Rất tiếc, mã <b>{coupon_code}</b> đã hết hạn hoặc hết lượt sử dụng.", 
                        parse_mode=ParseMode.HTML
                    )
                    coupon_code = None
                else:
                    discount = coupon_details.get('discount', 0)
                    final_price = max(0, ICLOUD_PACKAGE_PRICE - discount)
                    coupon_applied_text = f"🎉 Đã áp dụng coupon <b>{coupon_code.upper()}</b> (Giảm {discount:,} VNĐ)\n\n"
            else:
                await context.bot.send_message(user.id, "🎟️ Mã giảm giá không hợp lệ.")
                coupon_code = None
    except Exception as e:
        logger.error(f"Lỗi khi xử lý coupon: {e}")
        coupon_code = None

    # Tạo mã đơn hàng an toàn
    order_code = "ICLD" + ''.join(random.choices(string.digits, k=6))
    
    # Mã hóa thông tin để tránh lỗi
    try:
        encoded_add_info = quote(order_code)
        encoded_account_name = quote(ACCOUNT_NAME)
    except Exception as e:
        logger.error(f"Lỗi mã hóa thông tin: {e}")
        await context.bot.send_message(user.id, "❌ Lỗi hệ thống. Vui lòng thử lại sau.")
        return

    # Tạo QR link với nhiều kiểm tra
    qr_link = f"https://img.vietqr.io/image/{BANK_ID}-{BANK_ACCOUNT_NUMBER}-print.png?amount={final_price}&addInfo={encoded_add_info}&accountName={encoded_account_name}"
    
    # Kiểm tra QR link với timeout và xử lý lỗi
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.get(qr_link)
            response.raise_for_status()  # Ném ngoại lệ nếu status code không thành công
    except httpx.RequestError as e:
        logger.error(f"Lỗi khi kiểm tra QR code URL: {e}")
        await context.bot.send_message(user.id, "❌ Lỗi khi tạo mã QR. Vui lòng thử lại sau.")
        return
    except Exception as e:
        logger.error(f"Lỗi không xác định khi tạo QR: {e}")
        await context.bot.send_message(user.id, "❌ Đã có lỗi xảy ra. Vui lòng liên hệ hỗ trợ.")
        return

    # Tạo caption an toàn
    try:
        caption = (
            f"✨ <b>XÁC NHẬN ĐƠN HÀNG</b> ✨\n\n"
            f"Vui lòng thanh toán để hoàn tất đơn hàng cho email: <b>{email}</b>\n\n"
            f"{coupon_applied_text}"
            f"💰 <b>Số tiền cần thanh toán:</b> <pre>{final_price:,} VNĐ</pre>\n"
            f"🏦 <b>Thông tin chuyển khoản:</b>\n"
            f"   - Ngân hàng: <b>{BANK_ID} (Vietcombank)</b>\n"
            f"   - Tên TK: <b>{ACCOUNT_NAME}</b>\n"
            f"   - STK: <code>{BANK_ACCOUNT_NUMBER}</code>\n\n"
            f"❗️ <b>NỘI DUNG CHUYỂN KHOẢN (BẮT BUỘC):</b> <pre>{order_code}</pre>\n\n"
            f"⚠️ <b>Lưu ý:</b> Vui lòng chuyển khoản <b>đúng nội dung và số tiền sẽ tự động duyệt sau 1-3 phút</b>. "
            f"Giao dịch sẽ tự động hủy sau <b>{int(ORDER_EXPIRATION_SECONDS / 60)} phút</b>."
        )
    except Exception as e:
        logger.error(f"Lỗi khi tạo caption: {e}")
        await context.bot.send_message(user.id, "❌ Lỗi định dạng thông báo. Vui lòng thử lại.")
        return

    # Gửi QR với nhiều lớp xử lý lỗi
    try:
        sent_message = await context.bot.send_photo(
            chat_id=user.id, 
            photo=qr_link, 
            caption=caption, 
            parse_mode=ParseMode.HTML
        )
        
        # Lưu thông tin đơn hàng
        pending_orders[order_code] = {
            "user_id": user.id, 
            "full_name": user.full_name, 
            "username": user.username, 
            "email": email, 
            "amount": final_price, 
            "coupon_code": coupon_code, 
            "time": time.time(), 
            "message_id": sent_message.message_id
        }
        
        await save_data()
    except Exception as e:
        logger.error(f"Lỗi khi gửi mã QR cho user {user.id}: {e}")
        await context.bot.send_message(user.id, "Đã có lỗi xảy ra khi tạo mã QR. Vui lòng thử lại sau.")

async def check_payment_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    data_changed = False
    current_time = time.time()
    expired_codes = [code for code, details in list(pending_orders.items()) if current_time - details.get("time", 0) > ORDER_EXPIRATION_SECONDS]
    for code in expired_codes:
        if code in pending_orders:
            details = pending_orders.pop(code); data_changed = True
            try:
                await context.bot.edit_message_caption(chat_id=details['user_id'], message_id=details['message_id'], caption=f"⚠️ <b>GIAO DỊCH ĐÃ HẾT HẠN</b> ⚠️\n\nMã QR cho email <b>{details['email']}</b> đã hết hiệu lực. Vui lòng thực hiện lại.", parse_mode=ParseMode.HTML, reply_markup=create_back_button_menu("🛍️ Mua Lại", "muahang_start"))
            except (Forbidden, BadRequest): pass
    if not pending_orders:
        if data_changed: await save_data()
        return
    logger.info(f"CRON: Bắt đầu quét... Đơn chờ: {len(pending_orders)}")
    try:
        api_url = f"https://thueapibank.vn/historyapi{BANK_ID.lower()}v3/{API_PASSWORD}/{BANK_ACCOUNT_NUMBER}/{API_TOKEN}"
        response = await http_client.get(api_url); response.raise_for_status()
        api_data = response.json()
        transactions = api_data.get("transactions", [])
        for tx in transactions:
            tx_id, description, amount = tx.get("transactionID"), tx.get("description", ""), tx.get("amount", 0)
            if not all([tx_id, description, amount]) or tx_id in processed_transaction_ids: continue
            match = ORDER_CODE_SEARCH_REGEX.search(description.upper())  # Tối ưu: compiled regex
            if not match: continue
            order_code = match.group(0)
            if order_code in pending_orders:
                order_details = pending_orders[order_code]
                expected_amount, actual_amount = int(order_details["amount"]), int(amount)
                if actual_amount == expected_amount:
                    user_id, email = order_details["user_id"], order_details["email"]
                    completed_order = { "user_id": user_id, "order_code": order_code, "email": email, "amount": actual_amount, "coupon_used": order_details.get("coupon_code"), "link": "", "timestamp": current_time, "full_name": order_details.get("full_name"), "username": order_details.get("username") }
                    if available_links:
                        link_to_send = list(available_links)[0]
                        # FIX 3.1: Use .value to store string instead of Enum object
                        completed_order.update({"link": link_to_send, "status": OrderStatus.COMPLETED.value})
                        await context.bot.send_message(user_id, f"✅ <b>THANH TOÁN THÀNH CÔNG</b> ✅\n\nCảm ơn bạn! Link kích hoạt đã được gửi đến email <b>{email}</b>.", parse_mode=ParseMode.HTML, reply_markup=create_success_menu())
                        email_sent, _ = send_activation_email(email, f"Link kích hoạt gói iCloud 2TB - {order_code}", order_details.get("full_name", "bạn"), link_to_send)
                        admin_notification = (f"✅ <b>ĐƠN HÀNG MỚI</b>\n" f"🔸 <b>Mã đơn:</b> <code>{order_code}</code>\n" f"👤 <b>Khách:</b> {order_details.get('full_name')} (@{order_details.get('username') or 'N/A'})\n" f"📧 <b>Email:</b> <code>{email}</code> | 💰 <b>Giá:</b> {actual_amount:,} VNĐ\n" f"✉️ <b>Email:</b> {'Thành công' if email_sent else 'Thất bại'}")
                        await context.bot.send_message(ADMIN_USER_ID, admin_notification, parse_mode=ParseMode.HTML)
                    else:
                        # FIX 3.2: Use .value to store string instead of Enum object
                        completed_order["status"] = OrderStatus.PENDING_LINK.value
                        await context.bot.send_message(user_id, "✅ <b>THANH TOÁN THÀNH CÔNG</b>\n\nTuy nhiên, hệ thống đang tạm hết link. Admin sẽ gửi link cho bạn sớm nhất.", parse_mode=ParseMode.HTML)
                        await context.bot.send_message(ADMIN_USER_ID, f"🚨 <b>CẢNH BÁO: HẾT LINK!</b> 🚨\n\nKhách <b>{email}</b> đã thanh toán. Vui lòng <code>/addlink</code>.", parse_mode=ParseMode.HTML)
                    if order_details.get("coupon_code"):
                        coupon_code_used = order_details["coupon_code"].upper()
                        if coupon_code_used in coupons: coupons[coupon_code_used]['used'] = coupons[coupon_code_used].get('used', 0) + 1
                    order_history.append(completed_order)
                    processed_transaction_ids.add(tx_id)
                    del pending_orders[order_code]
                    data_changed = True
                else:
                    logger.warning(f"Giao dịch gần đúng! Code: {order_code}, Mong đợi: {expected_amount}, Thực tế: {actual_amount}")
                    alert_message = ( f"⚠️ <b>CẢNH BÁO GIAO DỊCH ĐÁNG NGỜ</b> ⚠️\n\n" f"Phát hiện giao dịch có mã đơn hàng đang chờ nhưng sai số tiền.\n\n" f"- <b>Mã đơn hàng:</b> <code>{order_code}</code>\n" f"- <b>Khách hàng:</b> {order_details.get('full_name')} (@{order_details.get('username') or 'N/A'})\n" f"- <b>Số tiền đúng:</b> <pre>{expected_amount:,} VNĐ</pre>\n" f"- <b>Số tiền đã chuyển:</b> <pre>{actual_amount:,} VNĐ</pre>\n\n" f"Vui lòng kiểm tra và xử lý thủ công. Giao dịch này chưa được tự động xử lý." )
                    await context.bot.send_message(ADMIN_USER_ID, alert_message, parse_mode=ParseMode.HTML); processed_transaction_ids.add(tx_id); data_changed = True
    except Exception as e: logger.error(f"❌ LỖI KHÔNG XÁC ĐỊNH TRONG check_payment_job: {e}", exc_info=True)
    if data_changed: await save_data()

async def cleanup_expired_coupons_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.info("CRON: Bắt đầu quét mã giảm giá không hợp lệ...")
    today = datetime.now().date(); invalid_codes = []
    for code, details in list(coupons.items()):
        is_expired, is_used_up = False, False
        expiry_str = details.get('expires')
        if expiry_str:
            try:
                if datetime.strptime(expiry_str, '%d-%m-%Y').date() < today: is_expired = True
            except ValueError: logger.warning(f"Lỗi định dạng ngày ở mã giảm giá '{code}': '{expiry_str}'")
        quantity = details.get('quantity')
        if isinstance(quantity, int) and details.get('used', 0) >= quantity: is_used_up = True
        if is_expired or is_used_up:
            reason = "hết hạn" if is_expired else "hết lượt sử dụng"; invalid_codes.append(f"{code} ({reason})"); del coupons[code]
    if invalid_codes:
        logger.info(f"🧹 Đã tự động xóa {len(invalid_codes)} mã giảm giá: {', '.join(invalid_codes)}"); await save_data()
        try:
            report_text = f"🧹 <b>BÁO CÁO DỌN DẸP HÀNG NGÀY</b>\n\nĐã tự động xóa <b>{len(invalid_codes)}</b> mã giảm giá không hợp lệ:\n- <code>" + "</code>\n- <code>".join(invalid_codes) + "</code>"
            await context.bot.send_message(chat_id=ADMIN_USER_ID, text=report_text, parse_mode=ParseMode.HTML)
        except Exception as e: logger.error(f"Không thể gửi tin nhắn báo cáo dọn dẹp cho admin: {e}")
    else: logger.info("CRON: Không có mã giảm giá nào cần dọn dẹp.")

# ==============================================================================
#  CÁC TRÌNH XỬ LÝ LỆNH VÀ TIN NHẮN
# ==============================================================================
async def check_if_banned(update: Update) -> bool:
    if update.effective_user.id in banned_users:
        message = "❌ Bạn đã bị cấm sử dụng bot này. Vui lòng liên hệ Admin."
        if update.message: await update.message.reply_text(message)
        elif update.callback_query: await update.callback_query.answer(message, show_alert=True)
        return True
    return False

async def clear_user_state(context: ContextTypes.DEFAULT_TYPE):
    keys_to_clear = ['state', 'purchase_email', 'report_order_code', 'report_photo_id', 'support_query', 'reply_to_user_id']
    for key in keys_to_clear: context.user_data.pop(key, None)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await check_if_banned(update): return
    await clear_user_state(context)
    user = update.effective_user; user_id_str = str(user.id)
    if user_id_str not in user_data_db:
        user_data_db[user_id_str] = { "first_name": user.first_name, "last_name": user.last_name, "username": user.username, "first_seen": datetime.now().isoformat() }; await save_data()
    await update.message.reply_html(f"Xin chào {user.mention_html()}!\n\n{MAIN_MENU_TEXT}", reply_markup=create_main_menu())

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await clear_user_state(context); await update.message.reply_html("Đã hủy hành động. Quay về menu chính.", reply_markup=create_main_menu())

async def text_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await check_if_banned(update): return
    user_state = context.user_data.get('state'); user_input = update.message.text.strip(); user = update.effective_user
    if user_state == 'awaiting_email':
        if not EMAIL_REGEX.match(user_input):  # Tối ưu: compiled regex
            await update.message.reply_text("📧 Email không hợp lệ, vui lòng kiểm tra và gửi lại."); return
        context.user_data['purchase_email'] = user_input.lower(); context.user_data['state'] = 'awaiting_coupon_choice'
        keyboard = [[InlineKeyboardButton("✅ Có", callback_data='coupon_yes'), InlineKeyboardButton("❌ Không", callback_data='coupon_no')]]
        await update.message.reply_text("🎟️ Bạn có mã giảm giá không?", reply_markup=InlineKeyboardMarkup(keyboard))
    elif user_state == 'awaiting_coupon_code':
        email = context.user_data.get('purchase_email')
        if not email:
            await update.message.reply_text("❌ Lỗi: Không tìm thấy email. Vui lòng bắt đầu lại bằng /start")
            await clear_user_state(context)
            return
        await clear_user_state(context)
        await generate_payment_qr(update, context, email, user_input)
    elif user_state == 'awaiting_report_order_code':
        order_code = user_input.upper()
        if not ORDER_CODE_REGEX.match(order_code):  # Tối ưu: compiled regex
            await update.message.reply_text("⚠️ Mã đơn hàng không hợp lệ. Vui lòng nhập lại hoặc /cancel để hủy."); return
        found_order = next((o for o in reversed(order_history) if o.get("order_code") == order_code), None)
        if not found_order or found_order.get("user_id") != user.id: await update.message.reply_text("❌ Không tìm thấy đơn hàng này hoặc đơn hàng không thuộc về bạn. Vui lòng kiểm tra lại mã hoặc /cancel để hủy."); return
        context.user_data['report_order_code'] = order_code; context.user_data['state'] = 'awaiting_report_photo'
        await update.message.reply_text("✅ Đã xác nhận đơn hàng. Tiếp theo, vui lòng gửi <b>một ảnh chụp màn hình</b> về lỗi bạn đang gặp phải.", parse_mode=ParseMode.HTML)
    elif user_state == 'awaiting_report_description':
        description, order_code, photo_id = user_input, context.user_data.get('report_order_code'), context.user_data.get('report_photo_id')
        if not all([order_code, photo_id]): await update.message.reply_text("❌ Đã có lỗi trong quá trình báo cáo. Vui lòng bắt đầu lại."); await clear_user_state(context); return
        found_order = next((o for o in reversed(order_history) if o.get("order_code") == order_code), None)
        admin_report_caption = (f"⚠️ <b>BÁO CÁO LỖI MỚI</b> ⚠️\n\n" f"<b>Từ:</b> {user.mention_html()} (ID: <code>{user.id}</code>)\n" f"<b>Username:</b> @{user.username or 'Không có'}\n\n" f"<b>CHI TIẾT ĐƠN HÀNG:</b>\n" f"  - Mã đơn: <code>{found_order['order_code']}</code>\n" f"  - Email: <code>{found_order['email']}</code>\n\n" f"<b>MÔ TẢ CỦA KHÁCH:</b>\n" f"<i>{description}</i>")
        resend_button = InlineKeyboardButton("➡️ Gửi Lại Link Cho Đơn Này", callback_data=f"resend_link:{found_order['user_id']}:{found_order['email']}")
        await context.bot.send_photo(chat_id=ADMIN_USER_ID, photo=photo_id, caption=admin_report_caption, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup([[resend_button]]))
        await update.message.reply_text("✅ Cảm ơn bạn! Báo cáo đã được gửi thành công đến Admin."); await clear_user_state(context)
    elif user_state == 'awaiting_support_query':
        query = update.message.text.strip(); context.user_data['support_query'] = query
        
        # Sử dụng intelligent_ticket_classifier để xử lý truy vấn hỗ trợ
        ai_result = await intelligent_ticket_classifier(query, user.id)
        
        if ai_result['auto_resolved']:
            # Nếu AI tự động giải quyết được
            await update.message.reply_html(ai_result['response'])
            await clear_user_state(context)
        else:
            # Nếu không thể tự động giải quyết
            keyboard = [
                [InlineKeyboardButton("✅ Hỏi Trợ lý AI", callback_data='ask_ai_confirm')], 
                [InlineKeyboardButton("📝 Tạo phiếu hỗ trợ cho Admin", callback_data='create_ticket_confirm')]
            ]
            await update.message.reply_text(
                "Câu hỏi của bạn cần sự tư vấn chi tiết hơn. Bạn có muốn hỏi Trợ lý AI của chúng tôi không?", 
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
    elif user_state and user_state.startswith('awaiting_admin_reply'):
        if update.effective_user.id != ADMIN_USER_ID: return
        target_user_id = int(user_state.split(':', 1)[1])
        try:
            await context.bot.send_message(chat_id=target_user_id, text="📬 <b>Bạn có phản hồi từ Admin:</b>", parse_mode=ParseMode.HTML)
            await context.bot.copy_message(chat_id=target_user_id, from_chat_id=update.message.chat_id, message_id=update.message.message_id)
            await update.message.reply_text("✅ Tin nhắn của bạn đã được gửi tới người dùng.")
        except Exception as e: await update.message.reply_text(f"❌ Gửi phản hồi thất bại. Lỗi: {e}")
        finally: await clear_user_state(context)

async def photo_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await check_if_banned(update): return
    if context.user_data.get('state') == 'awaiting_report_photo':
        context.user_data['report_photo_id'] = update.message.photo[-1].file_id; context.user_data['state'] = 'awaiting_report_description'
        await update.message.reply_text("✅ Đã nhận ảnh. Cuối cùng, vui lòng <b>mô tả ngắn gọn</b> vấn đề của bạn là gì.", parse_mode=ParseMode.HTML)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await check_if_banned(update): return
    query = update.callback_query; await query.answer()
    command, user_id = query.data, update.effective_user.id
    if command == 'back_to_main':
        await clear_user_state(context);
        try: await query.delete_message()
        except BadRequest: pass
        await context.bot.send_message(user_id, MAIN_MENU_TEXT, parse_mode=ParseMode.HTML, reply_markup=create_main_menu())
    elif command in {'huongdan', 'chinhsach'}:
        text_map = {'huongdan': HUONGDAN_TEXT, 'chinhsach': CHINHSACH_TEXT}; await query.edit_message_text(text_map[command], parse_mode=ParseMode.HTML, reply_markup=create_back_button_menu())
    elif command == 'lichsu_entry':
        try: await query.delete_message()
        except: pass
        await lichsu_command(update, context, is_callback=True)
    elif command == 'muahang_start':
        if not available_links: await context.bot.send_message(user_id, "🛠️ Rất xin lỗi, hệ thống đang tạm hết link mời. Vui lòng quay lại sau."); return
        try: await query.delete_message()
        except BadRequest: pass
        last_order = next((o for o in reversed(order_history) if o.get("user_id") == user_id and o.get("status") == OrderStatus.COMPLETED.value), None)
        if last_order and 'email' in last_order:
            last_email = last_order['email']
            keyboard = [[InlineKeyboardButton(f"✅ Dùng email: {last_email}", callback_data=f"use_last_email:{last_email}")], [InlineKeyboardButton("✏️ Nhập email khác", callback_data="enter_new_email")]]
            await context.bot.send_message(user_id, "Chào mừng trở lại! Bạn có muốn dùng email đã sử dụng lần trước không?", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            context.user_data['state'] = 'awaiting_email'; await context.bot.send_message(user_id, "📧 Vui lòng nhập email bạn muốn dùng để nhận link kích hoạt.", reply_markup=create_back_button_menu("Hủy", "back_to_main"))
    elif command.startswith('use_last_email:'):
        email = command.split(':', 1)[1]; context.user_data['purchase_email'] = email; context.user_data['state'] = 'awaiting_coupon_choice'
        keyboard = [[InlineKeyboardButton("✅ Có", callback_data='coupon_yes'), InlineKeyboardButton("❌ Không", callback_data='coupon_no')]]
        await query.message.edit_text("Tuyệt vời! Bạn có mã giảm giá không?", reply_markup=InlineKeyboardMarkup(keyboard))
    elif command == 'enter_new_email':
        context.user_data['state'] = 'awaiting_email'; await query.message.edit_text("📧 Vui lòng nhập email bạn muốn dùng để nhận link kích hoạt.", reply_markup=create_back_button_menu("Hủy", "back_to_main"))
    elif command == 'coupon_yes':
        context.user_data['state'] = 'awaiting_coupon_code'; await query.message.edit_text("📝 Vui lòng nhập mã giảm giá của bạn.")
    elif command == 'coupon_no':
        email = context.user_data.get('purchase_email'); await query.delete_message(); await clear_user_state(context); await generate_payment_qr(update, context, email)
    elif command == 'report_error':
        context.user_data['state'] = 'awaiting_report_order_code'
        try: await query.delete_message()
        except BadRequest: pass
        await context.bot.send_message(user_id, "<b>Báo cáo lỗi & Yêu cầu hỗ trợ</b>\n\nBắt đầu bằng cách nhập <b>Mã đơn hàng</b> của bạn (ví dụ: ICLD123456).\n\nGõ /cancel để hủy.", parse_mode=ParseMode.HTML)
    elif command.startswith('report_specific_order:'):
        order_code = command.split(':', 1)[1]; await query.message.edit_text(f"Đang xử lý yêu cầu báo lỗi cho đơn hàng <code>{order_code}</code>...", parse_mode=ParseMode.HTML, reply_markup=None)
        context.user_data['state'] = 'awaiting_report_photo'; context.user_data['report_order_code'] = order_code
        await query.message.reply_text("Tiếp theo, vui lòng gửi <b>một ảnh chụp màn hình</b> về lỗi bạn đang gặp phải.", parse_mode=ParseMode.HTML)
    elif command == 'lienhe_admin':
        try: await query.delete_message()
        except: pass
        context.user_data['state'] = 'awaiting_support_query'; await context.bot.send_message(user_id, "Vui lòng mô tả vấn đề hoặc câu hỏi của bạn. Trợ lý của chúng tôi sẽ phân tích và hỗ trợ bạn.", reply_markup=create_back_button_menu("Hủy", "back_to_main"))
    elif command == 'ask_ai_confirm':
        await query.edit_message_text("Đang kết nối với Trợ lý AI, vui lòng chờ trong giây lát...")
        question = context.user_data.get('support_query')
        if question:
            await context.bot.send_chat_action(chat_id=user_id, action=ChatAction.TYPING)
            ai_answer = await ask_gemini(question); await query.edit_message_text(f"🤖 <b>Trợ lý AI Dino trả lời:</b>\n\n{ai_answer}", parse_mode=ParseMode.HTML)
        else: await query.edit_message_text("Đã có lỗi xảy ra. Vui lòng bắt đầu lại.")
        await clear_user_state(context)
    elif command == 'create_ticket_confirm':
        query_text, user = context.user_data.get('support_query'), update.effective_user; ticket_id = f"TICKET-{random.randint(1000, 9999)}"
        admin_message_text = (f"🎟️ <b>PHIẾU HỖ TRỢ MỚI</b> ({ticket_id}) 🎟️\n\n" f"<b>Từ:</b> {user.mention_html()} (ID: <code>{user.id}</code>)\n" f"<b>Username:</b> @{user.username or 'Không có'}\n\n" f"<b>Nội dung:</b>\n<i>{query_text}</i>")
        reply_button = InlineKeyboardButton("✍️ Phản hồi User", callback_data=f"reply_to_ticket:{user.id}")
        await context.bot.send_message(ADMIN_USER_ID, admin_message_text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup([[reply_button]]))
        await query.edit_message_text(f"✅ Đã tạo phiếu hỗ trợ với mã <b>{ticket_id}</b>. Admin sẽ sớm phản hồi. Cảm ơn bạn!", parse_mode=ParseMode.HTML); await clear_user_state(context)
    elif command.startswith('reply_to_ticket:'):
        target_user_id = int(command.split(':', 1)[1]); context.user_data['state'] = f'awaiting_admin_reply:{target_user_id}'
        await query.message.edit_text(query.message.text_html + "\n\n<i>(Đang chờ phản hồi...)</i>", parse_mode=ParseMode.HTML, reply_markup=None)
        await query.answer(); await context.bot.send_message(chat_id=ADMIN_USER_ID, text=f"✍️ Vui lòng nhập nội dung phản hồi cho người dùng ID: <code>{target_user_id}</code>", parse_mode=ParseMode.HTML)
    elif command.startswith('resend_link:'):
        if query.from_user.id != ADMIN_USER_ID: await query.answer("Bạn không có quyền.", show_alert=True); return
        if not available_links: await query.answer("❌ HẾT LINK TRONG KHO!", show_alert=True); return
        try:
            _, target_user_id_str, target_email = command.split(':', 2); target_user_id, new_link = int(target_user_id_str), list(available_links)[0]
            new_caption = query.message.caption_html + f"\n\n<b>--- [ ĐÃ XỬ LÝ ] ---\n✅ Admin đã gửi lại link mới cho <code>{target_email}</code> lúc {datetime.now().strftime('%H:%M %d/%m')}.</b>"
            disabled_button = InlineKeyboardButton("➡️ Đã Xử Lý", callback_data=f"resend_link_handled:")
            await query.edit_message_caption(caption=new_caption, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup([[disabled_button]]))
            full_name = user_data_db.get(target_user_id_str, {}).get("first_name", "bạn")
            await context.bot.send_message(target_user_id, "🎉 <b>Admin đã gửi lại link kích hoạt cho bạn!</b>\nVui lòng kiểm tra email.", parse_mode=ParseMode.HTML)
            send_activation_email(target_email, "[Hỗ trợ] Link kích hoạt iCloud mới", full_name, new_link)
            for order in reversed(order_history):
                # FIX 3.3: Use .value to store string instead of Enum object
                if str(order.get("user_id")) == target_user_id_str and order.get("email") == target_email: order.update({'link': new_link, 'status': OrderStatus.COMPLETED_RESENT.value}); break
            await save_data()
        except Exception as e: logger.error(f"Lỗi khi gửi lại link: {e}", exc_info=True); await query.answer(f"Lỗi: {e}", show_alert=True)

# ==============================================================================
#  CÁC LỆNH
# ==============================================================================
async def admin_command_wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, func):
    if update.effective_user.id != ADMIN_USER_ID: return
    await func(update, context)

async def ask_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await check_if_banned(update): return
    # FIX 2: Escape HTML special characters
    if not context.args: await update.message.reply_html("Cú pháp: <code>/ask [câu hỏi]</code>"); return
    question = " ".join(context.args)
    await update.message.reply_chat_action(ChatAction.TYPING)
    ai_answer = await ask_gemini(question)
    await update.message.reply_html(f"🤖 <b>Trợ lý AI Dino trả lời:</b>\n\n{ai_answer}")

async def lichsu_command(update: Update, context: ContextTypes.DEFAULT_TYPE, is_callback: bool = False) -> None:
    if await check_if_banned(update): return
    chat_id, user_id = update.effective_chat.id, update.effective_user.id
    user_orders = [o for o in order_history if o.get("user_id") == user_id]
    if not user_orders: await context.bot.send_message(chat_id, "Bạn chưa có đơn hàng nào.", reply_markup=create_back_button_menu()); return
    if is_callback: await context.bot.send_message(chat_id, "<b>🧾 5 ĐƠN HÀNG GẦN NHẤT CỦA BẠN 🧾</b>\n---", parse_mode=ParseMode.HTML)
    for order in user_orders[-5:]:
        order_time, order_code = datetime.fromtimestamp(order['timestamp']).strftime('%H:%M %d/%m/%Y'), order.get('order_code', 'N/A')
        message = (f"<b>Đơn hàng ngày:</b> {order_time}\n" f"  - <b>Mã đơn:</b> <code>{order_code}</code>\n" f"  - <b>Email:</b> {order['email']}\n" f"  - <b>Trạng thái:</b> {status_text(order.get('status'))}")
        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("❗️ Báo lỗi đơn này", callback_data=f"report_specific_order:{order_code}")]]) if order_code != 'N/A' else None
        await context.bot.send_message(chat_id, message, parse_mode=ParseMode.HTML, reply_markup=keyboard); await asyncio.sleep(0.1)
    await context.bot.send_message(chat_id, "---", reply_markup=create_back_button_menu())

async def show_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id != ADMIN_USER_ID:
        await update.message.reply_text("❌ Bạn không có quyền truy cập lệnh này.")
        return
    admin_commands = (
        "👑 <b>BẢNG ĐIỀU KHIỂN ADMIN</b> 👑\n\n"
        "<b>Hỗ trợ &amp; AI:</b>\n"
        "<code>/ask [câu hỏi]</code> - Thử nghiệm AI Agent.\n\n"
        "<b>Thống kê:</b>\n"
        "<code>/doanhthu</code> - Xem thống kê doanh thu.\n"
        "<code>/rewardtop</code> - Tặng coupon cho KH mua nhiều nhất.\n\n"
        "<b>🔥 Marketing &amp; SALE:</b>\n"
        "<code>/sale [%] [số lượng] [ngày]</code> - Tạo SALE &amp; broadcast.\n"
        "<i>VD: /sale 30 50 7 = giảm 30%, 50 mã, 7 ngày</i>\n\n"
        "<b>✅ Duyệt đơn thủ công:</b>\n"
        "<code>/duyet</code> - Xem đơn chờ duyệt\n"
        "<code>/duyet [mã đơn]</code> - Duyệt đơn thủ công\n"
        "<i>VD: /duyet ICLD123456</i>\n\n"
        "<b>Quản lý Link Mời:</b>\n"
        "<code>/kholink</code> - Xem link mời đang sử dụng.\n"
        "<code>/addlink [link]</code> - Cập nhật link mời.\n"
        "<code>/removelink</code> - Xóa link mời khỏi kho.\n\n"
        "<b>Quản lý Coupon:</b>\n"
        "<code>/addcoupon [MÃ] [LƯỢNG] [TIỀN] [SỐ_NGÀY]</code>\n"
        "<code>/delcoupon [MÃ]</code>\n"
        "<code>/listcoupons</code>\n\n"
        "<b>Quản lý Người dùng:</b>\n"
        "<code>/listusers</code>\n"
        "<code>/userinfo [user_id]</code>\n"
        "<code>/broadcast</code> - Gửi tin (dùng reply).\n"
        "<code>/ban [user_id]</code> | <code>/unban [user_id]</code>\n\n"
        "<b>Xử lý Đơn hàng:</b>\n"
        "<code>/guilink [email] [link]</code>"
    )
    await update.message.reply_html(admin_commands)

async def kholink_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not available_links: await update.message.reply_text("📭 Kho link hiện đang trống.")
    else: await update.message.reply_html(f"📦 <b>LINK MỜI ĐANG SỬ DỤNG (DÙNG LẠI):</b>\n\n<code>{list(available_links)[0]}</code>")

async def addlink_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args: await update.message.reply_text("Cú pháp: /addlink <link_mới>"); return
    new_link = context.args[0]; available_links.clear(); available_links.add(new_link); await save_data()
    await update.message.reply_html(f"✅ <b>ĐÃ CẬP NHẬT LINK MỜI</b>\n\n🔗 <b>Link mới:</b> <code>{new_link}</code>")

async def removelink_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if available_links: available_links.clear(); await save_data(); await update.message.reply_text("🗑️ Đã xóa link mời khỏi kho.")
    else: await update.message.reply_text("Kho đã trống sẵn rồi.")

async def guilink_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2: await update.message.reply_text("Cú pháp: /guilink <email> <link>"); return
    email_to_find, link_to_send = context.args[0].lower(), context.args[1]
    order_found = next((o for o in reversed(order_history) if o["email"] == email_to_find and "Chờ link" in status_text(o.get("status"))), None)
    if order_found:
        try:
            # FIX 3.4: Use .value to store string instead of Enum object
            order_found.update({"link": link_to_send, "status": OrderStatus.COMPLETED_RESENT.value}); await save_data()
            full_name = order_found.get("full_name", "bạn")
            await context.bot.send_message(order_found["user_id"], "🎉 <b>Admin đã gửi link kích hoạt cho bạn!</b>\nVui lòng kiểm tra email.", parse_mode=ParseMode.HTML, reply_markup=create_success_menu())
            send_activation_email(email_to_find, "[Từ Admin] Link kích hoạt iCloud", full_name, link_to_send)
            await update.message.reply_text(f"✅ Đã gửi link thủ công thành công cho: {email_to_find}.")
        except Exception as e: logger.error(f"Lỗi khi gửi link thủ công: {e}"); await update.message.reply_text(f"❌ Gửi link thất bại! Lỗi: {e}")
    else: await update.message.reply_text("🔎 Không tìm thấy đơn hàng nào đang 'Chờ link' với email này.")

async def rewardtop_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("🔎 Bắt đầu tìm và tặng thưởng...")
    completed_orders = [o for o in order_history if "Hoàn thành" in status_text(o.get("status"))]
    if not completed_orders: await context.bot.send_message(update.effective_chat.id, "Chưa có đơn hàng hoàn tất để xếp hạng."); return
    user_purchase_counts = Counter(order['user_id'] for order in completed_orders)
    top_users = user_purchase_counts.most_common(2)
    admin_feedback = "🏆 <b>KẾT QUẢ TẶNG THƯỞNG KHÁCH HÀNG THÂN THIẾT</b> 🏆\n\n"; discount_amount = int(ICLOUD_PACKAGE_PRICE * 0.3)
    for user_id, purchase_count in top_users:
        user_info = user_data_db.get(str(user_id), {}); user_mention = user_info.get("first_name", f"ID {user_id}")
        coupon_code = f"VIP30-{''.join(random.choices(string.ascii_uppercase + string.digits, k=5))}"
        expires_str = (datetime.now() + timedelta(days=30)).strftime('%d-%m-%Y')
        coupons[coupon_code] = {"discount": discount_amount, "quantity": 1, "expires": expires_str, "used": 0}
        reward_message = (f"🎉 <b>CHÚC MỪNG KHÁCH HÀNG THÂN THIẾT</b> 🎉\n\nCảm ơn bạn đã ủng hộ DinoTools!\n" f"Chúng tôi xin gửi tặng bạn mã giảm giá <b>30%</b> cho lần mua tiếp theo: <code>{coupon_code}</code>\n" f"<i>(Mã dùng 1 lần, hết hạn ngày {expires_str})</i>")
        try: await context.bot.send_message(user_id, reward_message, parse_mode=ParseMode.HTML); admin_feedback += f"✅ Đã gửi coupon <code>{coupon_code}</code> cho {user_mention} ({purchase_count} đơn).\n"
        except Exception as e: admin_feedback += f"❌ Lỗi khi gửi coupon cho {user_mention}: {e}\n"
    await save_data(); await context.bot.send_message(update.effective_chat.id, admin_feedback, parse_mode=ParseMode.HTML)

async def addcoupon_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) != 4: await update.message.reply_html("Cú pháp: <code>/addcoupon <MÃ> <LƯỢNG> <TIỀN> <SỐ_NGÀY></code>"); return
    code, quantity_str, amount_str, days_str = context.args
    try: quantity, discount, days = map(int, [quantity_str, amount_str, days_str])
    except ValueError: await update.message.reply_text("Lượng, tiền và ngày phải là số."); return
    expires_str = (datetime.now() + timedelta(days=days)).strftime('%d-%m-%Y')
    coupons[code.upper()] = {"discount": discount, "quantity": quantity, "expires": expires_str, "used": 0}; await save_data()
    await update.message.reply_html(f"✅ Đã thêm/cập nhật coupon <b>{code.upper()}</b>")

async def delcoupon_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args: await update.message.reply_text("Cú pháp: /delcoupon <TÊN_MÃ>"); return
    code = context.args[0].upper()
    if code in coupons: del coupons[code]; await save_data(); await update.message.reply_html(f"🗑️ Đã xóa coupon <b>{code}</b>.")
    else: await update.message.reply_text("❌ Không tìm thấy coupon này.")

async def listcoupons_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not coupons: await update.message.reply_text("Hiện không có mã giảm giá nào."); return
    message = "<b>🎟️ DANH SÁCH MÃ GIẢM GIÁ 🎟️</b>\n\n";
    for code, details in coupons.items(): message += (f"- <code>{code}</code> | Giảm: <b>{details.get('discount', 0):,}đ</b>\n" f"  Đã dùng: <b>{details.get('used', 0)}/{details.get('quantity', '∞')}</b> | Hết hạn: <b>{details.get('expires', 'N/A')}</b>\n")
    await update.message.reply_html(message)

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message.reply_to_message:
        await update.message.reply_html("<b>💡 Hướng dẫn:</b>\n1. Soạn sẵn tin nhắn bạn muốn gửi.\n2. Gửi tin nhắn đó vào đây.\n3. Trả lời (Reply) lại tin nhắn vừa gửi bằng lệnh <code>/broadcast</code>.")
        return
    message_to_broadcast, all_users_ids = update.message.reply_to_message, list(user_data_db.keys())
    await update.message.reply_text(f"🚀 Bắt đầu gửi broadcast đến {len(all_users_ids)} người dùng...")
    success, fail, errors = 0, 0, []
    for user_id in all_users_ids:
        try:
            await context.bot.copy_message(chat_id=int(user_id), from_chat_id=update.message.chat_id, message_id=message_to_broadcast.message_id)
            success += 1; await asyncio.sleep(0.2) 
        except Exception as e:
            fail += 1
            if len(errors) < 5: errors.append(f"ID {user_id}: {type(e).__name__} - {e}")
    summary = f"✅ Gửi broadcast hoàn tất!\n- Thành công: {success}\n- Thất bại: {fail}"
    if errors: summary += "\n\n📋 <b>Chi tiết 5 lỗi đầu tiên:</b>\n" + "\n".join([f"- <code>{error}</code>" for error in errors])
    await update.message.reply_html(summary)

async def listusers_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not user_data_db: await update.message.reply_text("Chưa có người dùng nào."); return
    header = f"<b>👥 DANH SÁCH NGƯỜI DÙNG ({len(user_data_db)})</b>\n\n"; message_parts, current_part = [], header
    for uid, data in user_data_db.items():
        line = f"- {data.get('first_name','')} (@{data.get('username','N/A')})\n  ID: <code>{uid}</code>\n"
        if len(current_part) + len(line) > 4096: message_parts.append(current_part); current_part = ""
        current_part += line
    if current_part != header: message_parts.append(current_part)
    for part in message_parts: await update.message.reply_html(part); await asyncio.sleep(0.2)

async def userinfo_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args: await update.message.reply_text("Cú pháp: /userinfo <user_id>"); return
    try: target_id, target_id_str = int(context.args[0]), context.args[0]
    except (ValueError, IndexError): await update.message.reply_text("ID không hợp lệ."); return
    user_info = user_data_db.get(target_id_str)
    if not user_info: await update.message.reply_text("Không tìm thấy người dùng."); return
    user_orders = [o for o in order_history if o.get("user_id") == target_id]
    first_seen_str = user_info.get('first_seen'); first_seen = datetime.fromisoformat(first_seen_str).strftime('%d/%m/%Y %H:%M') if first_seen_str else 'N/A'
    message = (f"<b>ℹ️ THÔNG TIN USER</b>\n" f"<b>- Tên:</b> {user_info.get('first_name', '')} (@{user_info.get('username', 'N/A')})\n" f"<b>- ID:</b> <code>{target_id}</code>\n" f"<b>- Tình trạng:</b> {'🚫 Bị cấm' if target_id in banned_users else '✅ Hoạt động'}\n" f"<b>- Tham gia:</b> {first_seen}\n\n" f"<b>🛒 LỊCH SỬ MUA HÀNG ({len(user_orders)} đơn)</b>\n")
    if not user_orders: message += "<i>Chưa có đơn hàng.</i>"
    else: message += "\n".join([f"- {datetime.fromtimestamp(o['timestamp']).strftime('%d/%m/%Y')}: <code>{o.get('order_code', 'N/A')}</code> - {o['email']} - {status_text(o.get('status'))}" for o in user_orders])
    await update.message.reply_html(message)

async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args: await update.message.reply_text("Cú pháp: /ban <user_id>"); return
    try:
        target_id = int(context.args[0])
        if target_id == ADMIN_USER_ID: await update.message.reply_text("Không thể tự cấm mình."); return
        banned_users.add(target_id); await save_data(); await update.message.reply_text(f"🚫 Đã cấm người dùng ID: {target_id}.")
    except (ValueError, IndexError): await update.message.reply_text("ID không hợp lệ.")

async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args: await update.message.reply_text("Cú pháp: /unban <user_id>"); return
    try:
        target_id = int(context.args[0])
        if target_id in banned_users: banned_users.remove(target_id); await save_data(); await update.message.reply_text(f"✅ Đã bỏ cấm người dùng ID: {target_id}.")
        else: await update.message.reply_text("Người dùng này không bị cấm.")
    except (ValueError, IndexError): await update.message.reply_text("ID không hợp lệ.")

async def doanhthu_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    now = datetime.now(); today_revenue, month_revenue, total_revenue = 0, 0, 0; today_orders, month_orders, total_orders = 0, 0, 0
    completed_orders = [o for o in order_history if "Hoàn thành" in status_text(o.get("status"))]
    for order in completed_orders:
        amount = order.get("amount", ICLOUD_PACKAGE_PRICE); total_revenue += amount; total_orders += 1
        if 'timestamp' in order:
            order_time = datetime.fromtimestamp(order['timestamp'])
            if order_time.date() == now.date(): today_revenue += amount; today_orders += 1
            if order_time.month == now.month and order_time.year == now.year: month_revenue += amount; month_orders += 1
    await update.message.reply_html(f"📊 <b>THỐNG KÊ DOANH THU</b> 📊\n\n" f"☀️ <b>Hôm nay ({now.strftime('%d/%m')}):</b> {today_revenue:,} VNĐ ({today_orders} đơn)\n" f"🌙 <b>Tháng này ({now.strftime('%m/%Y')}):</b> {month_revenue:,} VNĐ ({month_orders} đơn)\n" f"💰 <b>Tổng cộng:</b> {total_revenue:,} VNĐ ({total_orders} đơn)")

async def sale_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Tạo SALE event với % giảm giá và tự động broadcast cho tất cả users
    Cú pháp: /sale <% giảm> <số lượng> <số ngày>
    Ví dụ: /sale 30 50 7 (giảm 30%, 50 mã, hết hạn sau 7 ngày)
    """
    if len(context.args) != 3:
        await update.message.reply_html(
            "<b>📢 TẠO SALE EVENT</b>\n\n"
            "Cú pháp: <code>/sale [% giảm] [số lượng] [số ngày]</code>\n\n"
            "<b>Ví dụ:</b>\n"
            "<code>/sale 30 50 7</code>\n"
            "→ Giảm 30%, 50 mã, hết hạn sau 7 ngày\n\n"
            "<b>Bot sẽ tự động:</b>\n"
            "• Tạo mã giảm giá theo %\n"
            "• Broadcast thông báo SALE đẹp mắt\n"
            "• Gửi đến tất cả users"
        )
        return
    
    try:
        discount_percent = int(context.args[0])
        quantity = int(context.args[1])
        days = int(context.args[2])
        
        if not (1 <= discount_percent <= 100):
            await update.message.reply_text("❌ % giảm giá phải từ 1-100%")
            return
        
        if quantity < 1:
            await update.message.reply_text("❌ Số lượng phải > 0")
            return
            
        if days < 1:
            await update.message.reply_text("❌ Số ngày phải > 0")
            return
        
    except ValueError:
        await update.message.reply_text("❌ Vui lòng nhập số hợp lệ!")
        return
    
    # Tính toán
    discount_amount = int(ICLOUD_PACKAGE_PRICE * discount_percent / 100)
    final_price = ICLOUD_PACKAGE_PRICE - discount_amount
    expires_date = datetime.now() + timedelta(days=days)
    expires_str = expires_date.strftime('%d-%m-%Y')
    
    # Tạo mã coupon đẹp
    sale_code = f"SALE{discount_percent}-{''.join(random.choices(string.ascii_uppercase + string.digits, k=4))}"
    
    # Lưu coupon vào database
    coupons[sale_code] = {
        "discount": discount_amount,
        "quantity": quantity,
        "expires": expires_str,
        "used": 0
    }
    await save_data()
    
    # Thông báo cho admin trước
    admin_preview = (
        f"✅ <b>ĐÃ TẠO SALE EVENT THÀNH CÔNG!</b>\n\n"
        f"🎟️ <b>Mã giảm giá:</b> <code>{sale_code}</code>\n"
        f"💥 <b>Giảm:</b> {discount_percent}% ({discount_amount:,} VNĐ)\n"
        f"📦 <b>Số lượng:</b> {quantity} mã\n"
        f"⏰ <b>Hết hạn:</b> {expires_str}\n"
        f"💰 <b>Giá sau giảm:</b> {final_price:,} VNĐ\n\n"
        f"🚀 <b>Đang broadcast đến {len(user_data_db)} users...</b>"
    )
    await update.message.reply_html(admin_preview)
    
    # Tạo thông báo SALE siêu đẹp cho users
    sale_message = (
        f"🔥🔥🔥 <b>FLASH SALE - GIẢM GIÁ SỐC!</b> 🔥🔥🔥\n\n"
        f"⚡️ <b>GIẢM NGAY {discount_percent}%</b> ⚡️\n"
        f"Gói iCloud 2TB Vĩnh Viễn\n\n"
        f"💸 <b>Giá gốc:</b> <s>{ICLOUD_PACKAGE_PRICE:,} VNĐ</s>\n"
        f"🎯 <b>Giá SALE:</b> <b><u>{final_price:,} VNĐ</u></b>\n"
        f"💰 <b>Tiết kiệm:</b> {discount_amount:,} VNĐ!\n\n"
        f"🎟️ <b>MÃ GIẢM GIÁ:</b>\n"
        f"<code>{sale_code}</code>\n"
        f"<i>(Chạm để copy)</i>\n\n"
        f"⏰ <b>Chỉ có {quantity} mã</b>\n"
        f"📅 <b>Hết hạn:</b> {expires_date.strftime('%d/%m/%Y')}\n\n"
        f"⚡️ <b>NHANH TAY KẺO HẾT!</b> ⚡️\n\n"
        f"👉 Bấm /start để mua ngay!"
    )
    
    # Broadcast đến tất cả users
    success_count = 0
    fail_count = 0
    
    for user_id_str in user_data_db.keys():
        try:
            user_id = int(user_id_str)
            if user_id in banned_users:
                continue
            
            await context.bot.send_message(
                chat_id=user_id,
                text=sale_message,
                parse_mode=ParseMode.HTML
            )
            success_count += 1
            await asyncio.sleep(0.05)  # Tránh rate limit
            
        except Exception as e:
            fail_count += 1
            if fail_count <= 3:  # Log 3 lỗi đầu tiên
                logger.warning(f"Không thể gửi SALE cho user {user_id_str}: {e}")
    
    # Báo cáo kết quả cho admin
    result_message = (
        f"📊 <b>BÁO CÁO BROADCAST SALE</b>\n\n"
        f"✅ <b>Gửi thành công:</b> {success_count}\n"
        f"❌ <b>Thất bại:</b> {fail_count}\n"
        f"📦 <b>Tổng users:</b> {len(user_data_db)}\n\n"
        f"🎟️ <b>Mã:</b> <code>{sale_code}</code>\n"
        f"💥 <b>Giảm:</b> {discount_percent}% ({discount_amount:,} VNĐ)\n"
        f"📦 <b>Còn lại:</b> {quantity} mã\n\n"
        f"🎉 <b>SALE EVENT ĐÃ KHỞI ĐỘNG!</b>"
    )
    await context.bot.send_message(
        chat_id=ADMIN_USER_ID,
        text=result_message,
        parse_mode=ParseMode.HTML
    )

async def duyet_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Duyệt đơn hàng thủ công khi API không tự động duyệt
    Cú pháp: /duyet <mã đơn> hoặc chỉ /duyet để xem danh sách đơn chờ
    """
    # Hiển thị danh sách đơn chờ nếu không có args
    if not context.args:
        if not pending_orders:
            await update.message.reply_html(
                "<b>✅ KHÔNG CÓ ĐƠN HÀNG CHỜ DUYỆT</b>\n\n"
                "Tất cả đơn hàng đã được xử lý tự động.\n\n"
                "💡 <b>Cách dùng:</b>\n"
                "<code>/duyet [mã đơn]</code>\n"
                "VD: <code>/duyet ICLD123456</code>"
            )
            return
        
        # Hiển thị danh sách đơn chờ
        message = "<b>📋 DANH SÁCH ĐƠN HÀNG CHỜ DUYỆT</b>\n\n"
        for order_code, details in pending_orders.items():
            time_ago = int((time.time() - details.get('time', 0)) / 60)
            message += (
                f"🔸 <code>{order_code}</code>\n"
                f"   • Email: <b>{details['email']}</b>\n"
                f"   • Số tiền: <b>{details['amount']:,} VNĐ</b>\n"
                f"   • Chờ: <b>{time_ago} phút</b>\n"
                f"   • User: {details.get('full_name', 'N/A')}\n\n"
            )
        
        message += (
            "\n💡 <b>Để duyệt thủ công:</b>\n"
            "<code>/duyet [mã đơn]</code>\n"
            "VD: <code>/duyet ICLD123456</code>"
        )
        
        await update.message.reply_html(message)
        return
    
    # Duyệt đơn hàng thủ công
    order_code = context.args[0].upper()
    
    # Validate mã đơn
    if not ORDER_CODE_REGEX.match(order_code):
        await update.message.reply_html(
            "❌ <b>MÃ ĐƠN HÀNG KHÔNG HỢP LỆ</b>\n\n"
            "Mã đơn phải có dạng: <code>ICLD123456</code>"
        )
        return
    
    # Kiểm tra đơn hàng có trong pending không
    if order_code not in pending_orders:
        await update.message.reply_html(
            f"❌ <b>KHÔNG TÌM THẤY ĐƠN HÀNG</b>\n\n"
            f"Mã <code>{order_code}</code> không có trong danh sách chờ duyệt.\n\n"
            f"💡 Dùng <code>/duyet</code> để xem tất cả đơn chờ."
        )
        return
    
    # Lấy thông tin đơn hàng
    order_details = pending_orders[order_code]
    user_id = order_details["user_id"]
    email = order_details["email"]
    amount = order_details["amount"]
    full_name = order_details.get("full_name", "Khách hàng")
    
    # Kiểm tra có link không
    if not available_links:
        await update.message.reply_html(
            f"⚠️ <b>CẢNH BÁO: HẾT LINK!</b>\n\n"
            f"Đơn hàng <code>{order_code}</code> đã được xác nhận nhưng hệ thống đang hết link.\n\n"
            f"📧 Email: <b>{email}</b>\n"
            f"💰 Số tiền: <b>{amount:,} VNĐ</b>\n\n"
            f"Vui lòng <code>/addlink</code> trước khi duyệt!"
        )
        return
    
    # Xử lý duyệt đơn
    try:
        current_time = time.time()
        link_to_send = list(available_links)[0]
        
        # Tạo đơn hàng hoàn thành
        completed_order = {
            "user_id": user_id,
            "order_code": order_code,
            "email": email,
            "amount": amount,
            "coupon_used": order_details.get("coupon_code"),
            "link": link_to_send,
            "status": OrderStatus.COMPLETED.value,
            "timestamp": current_time,
            "full_name": full_name,
            "username": order_details.get("username"),
            "manual_approval": True  # Đánh dấu là duyệt thủ công
        }
        
        # Gửi link cho user
        await context.bot.send_message(
            user_id,
            f"✅ <b>ĐƠN HÀNG ĐÃ ĐƯỢC DUYỆT THỦ CÔNG!</b>\n\n"
            f"Mã đơn: <code>{order_code}</code>\n"
            f"Link kích hoạt đã được gửi đến email <b>{email}</b>\n\n"
            f"📧 Vui lòng kiểm tra hộp thư (kể cả spam).",
            parse_mode=ParseMode.HTML,
            reply_markup=create_success_menu()
        )
        
        # Gửi email
        email_sent, _ = send_activation_email(
            email,
            f"[Duyệt thủ công] Link kích hoạt - {order_code}",
            full_name,
            link_to_send
        )
        
        # Xóa khỏi pending và thêm vào history
        del pending_orders[order_code]
        order_history.append(completed_order)
        
        # Update coupon nếu có
        if order_details.get("coupon_code"):
            coupon_code_used = order_details["coupon_code"].upper()
            if coupon_code_used in coupons:
                coupons[coupon_code_used]['used'] = coupons[coupon_code_used].get('used', 0) + 1
        
        await save_data(force=True)
        
        # Thông báo cho admin
        success_message = (
            f"✅ <b>ĐÃ DUYỆT ĐƠN HÀNG THÀNH CÔNG!</b>\n\n"
            f"🔸 <b>Mã đơn:</b> <code>{order_code}</code>\n"
            f"👤 <b>Khách hàng:</b> {full_name}\n"
            f"📧 <b>Email:</b> <code>{email}</code>\n"
            f"💰 <b>Số tiền:</b> {amount:,} VNĐ\n"
            f"🔗 <b>Link:</b> Đã gửi\n"
            f"✉️ <b>Email:</b> {'✅ Thành công' if email_sent else '⚠️ Thất bại'}\n\n"
            f"📊 <b>Còn {len(pending_orders)} đơn chờ duyệt</b>"
        )
        
        await update.message.reply_html(success_message)
        
    except Exception as e:
        logger.error(f"Lỗi khi duyệt đơn thủ công: {e}", exc_info=True)
        await update.message.reply_html(
            f"❌ <b>LỖI KHI DUYỆT ĐƠN!</b>\n\n"
            f"Mã đơn: <code>{order_code}</code>\n"
            f"Lỗi: <code>{str(e)}</code>\n\n"
            f"Vui lòng thử lại hoặc kiểm tra log."
        )

# ==============================================================================
#  HÀM MAIN (KHỞI CHẠY BOT)
# ==============================================================================
def main() -> None:
    if not all([TELEGRAM_TOKEN, API_PASSWORD, API_TOKEN]):
        logger.critical("!!! CẢNH BÁO: Thiếu biến cấu hình cần thiết !!!")
        return

    load_data()
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    application.add_handler(CommandHandler(["start", "menu"], start_command))
    application.add_handler(CommandHandler("cancel", cancel_command))
    application.add_handler(CommandHandler("lichsu", lichsu_command))
    application.add_handler(CommandHandler("ask", ask_command))
    application.add_handler(CallbackQueryHandler(button_handler))
    
    # FIX 1: Dòng gây lỗi NameError đã được vô hiệu hóa.
    # application.add_handler(MessageHandler(filters.REPLY & ~filters.COMMAND, ticket_reply_handler))
    
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message_handler))
    application.add_handler(MessageHandler(filters.PHOTO, photo_message_handler))
    
    admin_handlers = {
        "show": show_command, "kholink": kholink_command, "addlink": addlink_command,
        "removelink": removelink_command, "guilink": guilink_command,
        "rewardtop": rewardtop_command, "addcoupon": addcoupon_command,
        "delcoupon": delcoupon_command, "listcoupons": listcoupons_command,
        "broadcast": broadcast_command, "listusers": listusers_command,
        "userinfo": userinfo_command, "ban": ban_command, "unban": unban_command,
        "doanhthu": doanhthu_command, "sale": sale_command, "duyet": duyet_command
    }
    for command, func in admin_handlers.items():
        application.add_handler(CommandHandler(command, lambda u, c, f=func: admin_command_wrapper(u, c, f)))

    job_queue = application.job_queue
    job_queue.run_repeating(check_payment_job, interval=BANK_CHECK_INTERVAL_SECONDS, first=10)
    job_queue.run_daily(cleanup_expired_coupons_job, time=dt_time(hour=0, minute=5, tzinfo=ZoneInfo("Asia/Ho_Chi_Minh")), name="daily_coupon_cleanup")
    
    # Tối ưu: Background task để debounced save
    job_queue.run_repeating(save_data_debounced, interval=_cache["save_debounce"], first=5)

    logger.info("🚀 Bot đã khởi động - Đã tối ưu siêu nhanh!")
    
    # Tối ưu: Cấu hình polling để phản hồi nhanh hơn
    application.run_polling(
        poll_interval=0.5,  # Giảm xuống 0.5s để phản hồi nhanh hơn
        timeout=10,  # Giảm timeout để không chờ lâu
        drop_pending_updates=True  # Bỏ qua updates cũ
    )

if __name__ == "__main__":
    main()
