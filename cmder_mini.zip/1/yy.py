from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

BOT_TOKEN = "8347197392:AAERwPzlH5FtV4rbOY010A4pAbV3hdBPh1E"
GROUP_ID = -1002191171631
ADMIN_ID = 7193749511

async def document_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle APK file upload from admin"""
    user_id = update.effective_user.id
    
    # Check if admin
    if user_id != ADMIN_ID:
        return
    
    # Get file info
    document = update.message.document
    if document and document.file_name.endswith('.apk'):
        file_id = document.file_id
        file_name = document.file_name
        
        await update.message.reply_text(
            f"📦 APK received: {file_name}\n"
            f"🆔 File ID: `{file_id}`\n\n"
            f"Send command:\n"
            f"`/update {file_id} v2.0`",
            parse_mode='Markdown'
        )

async def update_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /update command from admin"""
    user_id = update.effective_user.id
    
    # Check if admin
    if user_id != ADMIN_ID:
        await update.message.reply_text("❌ Unauthorized")
        return
    
    # Parse: /update <file_id> <version>
    try:
        file_id = context.args[0]
        version = context.args[1]
        
        # Send APK to group
        await context.bot.send_document(
            chat_id=GROUP_ID,
            document=file_id,
            caption=f"🔄 UPDATE AVAILABLE\n📦 Version: {version}\n\nDownload & install!"
        )
        
        await update.message.reply_text(f"✅ APK sent to group!")
        
    except (IndexError, ValueError):
        await update.message.reply_text(
            "Usage: /update <file_id> <version>\n\n"
            "1. First send APK file\n"
            "2. Copy file_id from bot reply\n"
            "3. Send: /update <file_id> <version>"
        )

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    
    # Handle APK file upload
    app.add_handler(MessageHandler(filters.Document.APK, document_handler))
    
    # Handle /update command
    app.add_handler(CommandHandler("update", update_command))
    
    print("✅ Bot started!")
    print("📌 Admin ID:", ADMIN_ID)
    print("📌 Group ID:", GROUP_ID)
    app.run_polling()

if __name__ == '__main__':
    main()
