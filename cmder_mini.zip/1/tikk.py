import requests
import time

# List of URLs to be requested
urls = [
    "https://Cheotuongtac.net/api/v1/payment/Vietcombank",
    "https://Cheotuongtac.net/api/v1/clf/0",
    "https://cheotuongtac.net/api/update",
    "https://cheotuongtac.net/api/v1/refill/status/childpanel",
    "https://cheotuongtac.net/api/v1/order/schedule/child/123",
    "https://cheotuongtac.net/api/v1/update/services/sitecon",
    "https://cheotuongtac.net/api/telegram/weere"
]

def cron_job():
    """
    Function to perform the cron job.
    It iterates through the list of URLs and sends a GET request to each.
    """
    for url in urls:
        try:
            # Send a GET request to the URL with a timeout
            response = requests.get(url, timeout=10)
            # Print the status code and URL for verification
            print(f"Request to {url} successful. Status code: {response.status_code}")
        except requests.exceptions.RequestException as e:
            # Handle any errors that occur during the request
            print(f"Request to {url} failed. Error: {e}")

def main():
    """
    Main function to run the cron job indefinitely every 60 seconds.
    """
    while True:
        print("\n--- Starting cron job ---")
        cron_job()
        print("--- Cron job finished. Waiting for 60 seconds... ---")
        # Wait for 60 seconds before the next run
        time.sleep(60)

if __name__ == "__main__":
    main()

