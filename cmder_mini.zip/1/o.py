

import asyncio
import time
import telebot
import qrcode
import io
import requests
import tempfile
import subprocess
import sys
import random
import json
import os
import sqlite3
import hashlib
import zipfile
import logging # <<< Tích hợp thư viện logging
import traceback # <<< Để xử lý lỗi trong vòng lặp chính
from datetime import datetime, timedelta, date
from threading import Lock
from bs4 import BeautifulSoup
from PIL import Image, ImageOps, ImageDraw, ImageFont
from io import BytesIO
from urllib.parse import urljoin, urlparse, urldefrag
from telebot import TeleBot, types
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import google.generativeai as genai
from gtts import gTTS
import psutil
import platform
import aiohttp

# --- Cấu hình Logging ---
# Ghi log ra file và hiển thị trên console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("bot_activity.log"),
        logging.StreamHandler()
    ]
)

# --- Bot Configuration ---
TOKEN = '6939568666:AAGIxvJo92a2rpDaHIb_9zjc7-qs-GrO62E'  # <--- THAY THẾ BẰNG TOKEN BOT CỦA BẠN
ADMIN_ID = 7193749511   # <--- THAY THẾ BẰNG USER ID ADMIN CỦA BẠN
ALLOWED_GROUP_ID = -1002191171631 # <--- THAY THẾ BẰNG ID NHÓM CHAT CỦA BẠN
DB_FILE = 'user_data.db'
VIP_PRICE = "60K"
VIP_DURATION_DAYS = 30
ADMIN_USERNAME = "dichcutelegram" # <--- THAY THẾ BẰNG USERNAME TELEGRAM CỦA BẠN (không có @)
BOT_USERNAME = "spampython_bot"  # <--- THAY THẾ BẰNG USERNAME BOT CỦA BẠN (không có @)
CHAT_GROUP_LINK = "https://t.me/dinotoolk" # <--- THAY THẾ BẰNG LINK NHÓM CHAT CỦA BẠN
GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY' # <--- THAY THẾ BẰNG GEMINI API KEY CỦA BẠN
PAYMENT_IMAGE_URL = 'https://i.imgur.com/FEC2Gbf.jpeg' # <--- THAY THẾ BẰNG URL ẢNH QR THANH TOÁN
API_KEY_THACHMORA = "autp-250"

# --- Feature Settings ---
FREE_SPAM_COOLDOWN = 100
VIP_SPAM_COOLDOWN = 50
FREE_SPAM_LIMIT = 2
VIP_SMS_LIMIT = 50
VIP_CALL_LIMIT = 30

# --- Global Variables ---
bot = TeleBot(TOKEN, parse_mode='Markdown')
admins = {ADMIN_ID}
allowed_users = []
bot_active = True
admin_mode = False
free_spam_enabled = True
private_chat_enabled = False
start_time = time.time()
last_usage = {}
running_spams = {}
blacklist = {"112", "113", "114", "115"}
users_requested_payment = {}

# --- Database Setup (Tối ưu với `with` statement) ---
def init_db():
    """Initializes the SQLite database and table if they don't exist."""
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    expiration_time TEXT,
                    username TEXT
                )
            ''')
        logging.info("Database initialized successfully.")
    except sqlite3.Error as e:
        logging.error(f"Database initialization failed: {e}", exc_info=True)

def load_users_from_database():
    """Loads active VIP user IDs from the database into the allowed_users list."""
    global allowed_users
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            cursor.execute('SELECT user_id FROM users WHERE expiration_time IS NULL OR expiration_time >= ?', (now_str,))
            rows = cursor.fetchall()
            allowed_users = [row[0] for row in rows]
            logging.info(f"Loaded {len(allowed_users)} active VIP users from database.")
    except sqlite3.Error as e:
        logging.error(f"Error loading users from database: {e}", exc_info=True)
        allowed_users = []

def save_user_to_database(user_id, expiration_time, username=None):
    """Saves or updates a user and updates the in-memory cache."""
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            expiration_str = expiration_time.strftime('%Y-%m-%d %H:%M:%S') if expiration_time else None
            cursor.execute(
                'INSERT OR REPLACE INTO users (user_id, expiration_time, username) VALUES (?, ?, ?)',
                (user_id, expiration_str, username)
            )
            logging.info(f"Saved user {user_id} (Username: {username}, Expiry: {expiration_str or 'Permanent'}) to DB.")
            
            # Tối ưu: Cập nhật cache trực tiếp
            if user_id not in allowed_users:
                allowed_users.append(user_id)
                logging.info(f"User {user_id} added to in-memory VIP cache.")

    except sqlite3.Error as e:
        logging.error(f"Error saving user {user_id} to database: {e}", exc_info=True)

def remove_user_from_database(user_id):
    """Removes a user from the database and the in-memory cache."""
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM users WHERE user_id = ?', (user_id,))
            logging.info(f"Removed user {user_id} from database.")

            # Tối ưu: Cập nhật cache trực tiếp
            if user_id in allowed_users:
                allowed_users.remove(user_id)
                logging.info(f"User {user_id} removed from in-memory VIP cache.")

    except sqlite3.Error as e:
        logging.error(f"Error removing user {user_id} from database: {e}", exc_info=True)

def delete_expired_users_from_db():
    """Deletes users whose VIP subscription has expired."""
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            deleted_count = cursor.execute('DELETE FROM users WHERE expiration_time IS NOT NULL AND expiration_time < ?', (now_str,)).rowcount
            if deleted_count > 0:
                logging.info(f"Deleted {deleted_count} expired users from database.")
                # Tải lại cache sau khi xóa hàng loạt
                load_users_from_database()
            return deleted_count
    except sqlite3.Error as e:
        logging.error(f"Error deleting expired users from database: {e}", exc_info=True)
        return 0

# --- Gemini AI Setup ---
try:
    if GEMINI_API_KEY and GEMINI_API_KEY != 'YOUR_GEMINI_API_KEY':
        genai.configure(api_key=GEMINI_API_KEY)
        gemini_model = genai.GenerativeModel(model_name="gemini-pro")
        gemini_chat_session = gemini_model.start_chat(history=[])
        logging.info("Gemini AI Model initialized successfully.")
    else:
        gemini_model = None
        logging.warning("Gemini AI key not configured. /gg command will be disabled.")
except Exception as e:
    logging.error(f"Error initializing Gemini AI: {e}", exc_info=True)
    gemini_model = None

# --- Helper Functions ---
def is_admin(user_id):
    return user_id in admins

def delete_user_message(message):
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except telebot.apihelper.ApiTelegramException as e:
        if 'message to delete not found' not in str(e) and 'message can\'t be deleted' not in str(e):
             logging.warning(f"Could not delete message {message.message_id} in chat {message.chat.id}: {e}")
    except Exception as e:
        logging.error(f"Unexpected error deleting message {message.message_id}: {e}", exc_info=True)

def check_bot_status(message):
    if not bot_active:
        bot.reply_to(message, '🤖 Bot hiện đang tạm dừng hoạt động.')
        delete_user_message(message)
        return False
    if admin_mode and not is_admin(message.from_user.id):
        bot.reply_to(message, '⚙️ Chế độ bảo trì đang bật, chỉ Admin có thể dùng lệnh.')
        delete_user_message(message)
        return False
    return True

def check_group_or_chat_mode(message):
    if not private_chat_enabled and message.chat.id != ALLOWED_GROUP_ID:
        try:
            bot.reply_to(message, f'🔔 Vui lòng sử dụng bot trong nhóm chat chỉ định: {CHAT_GROUP_LINK}')
            delete_user_message(message)
        except Exception as e:
             logging.error(f"Error replying or deleting in wrong chat {message.chat.id}: {e}", exc_info=True)
        return False
    return True

def get_user_mention(user):
    if not user:
        return "Người dùng không xác định"
    if user.username:
        return f"@{user.username}"
    else:
        return f"[{user.first_name or 'User'}](tg://user?id={user.id})"

def mask_phone(phone_number):
    if isinstance(phone_number, str) and len(phone_number) > 6:
        return f"{phone_number[:3]}***{phone_number[-3:]}"
    elif isinstance(phone_number, str) and len(phone_number) > 0:
         return f"{phone_number[0]}***{phone_number[-1]}"
    return "***"

def format_timedelta(delta):
    """Formats a timedelta object into a human-readable string (days, hours, minutes)."""
    if delta is None: return "N/A"
    total_seconds = int(delta.total_seconds())
    if total_seconds < 0: return "đã qua"
    days, rem = divmod(total_seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, _ = divmod(rem, 60)
    parts = []
    if days > 0: parts.append(f"{days} ngày")
    if hours > 0: parts.append(f"{hours} giờ")
    if minutes > 0 and days == 0: parts.append(f"{minutes} phút")
    if not parts: return "dưới 1 phút"
    return ", ".join(parts)

# --- Bot Command Handlers ---

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user = message.from_user
    welcome_text = f"👋 Xin chào {get_user_mention(user)}!\n\nTôi là *DINO BOT* 🦖, trợ lý của bạn.\nChọn một tùy chọn bên dưới:"
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("💰 Mua VIP", callback_data='buy_vip'),
        InlineKeyboardButton("📜 Danh Sách Lệnh", callback_data='show_commands'),
        InlineKeyboardButton("👥 Nhóm Chat", url=CHAT_GROUP_LINK),
        InlineKeyboardButton("🧑‍💻 Liên Hệ Admin", url=f"https://t.me/{ADMIN_USERNAME}")
    )
    bot.reply_to(message, welcome_text, reply_markup=markup)
    delete_user_message(message)

@bot.callback_query_handler(func=lambda call: call.data in ['buy_vip', 'show_commands'])
def handle_menu_callbacks(call):
    bot.answer_callback_query(call.id)
    if call.data == 'buy_vip':
        mua_command(call.message, from_callback=True, callback_user=call.from_user)
    elif call.data == 'show_commands':
        help_text = get_help_text(call.from_user.id)
        try:
            bot.edit_message_text(help_text, call.message.chat.id, call.message.message_id, reply_markup=call.message.reply_markup)
        except telebot.apihelper.ApiTelegramException as e:
            if "message is not modified" not in str(e):
                logging.warning(f"Error editing message for commands: {e}")

def get_help_text(user_id):
    is_user_admin = is_admin(user_id)
    name_bot = "DINO TOOL"
    response = (
        f"🦖 *{name_bot} - Danh Sách Lệnh*\n\n"
        f"*Lệnh Chung:*\n"
        f"`/start` - Menu chính\n"
        f"`/mua` - 💰 Mua VIP ({VIP_PRICE}/{VIP_DURATION_DAYS} ngày)\n"
        f"`/plan` - 📅 Kiểm tra hạn VIP\n"
        f"`/id` - 🆔 Lấy User ID\n"
        f"`/qr` <nội dung> - 🖼️ Tạo mã QR\n"
        f"`/voice` <văn bản> - 🗣️ Text-to-Speech\n"
        f"`/gg` <câu hỏi> - 🧠 Chat với Gemini AI\n"
        f"`/face` - 🧑 Ảnh mặt người ngẫu nhiên\n"
        f"`/tiktok` <link> - 🎵 Tải video/nhạc TikTok\n"
        f"`/tool` - 🛠️ Link tải công cụ khác\n"
        f"`/time` - ⏱️ Thời gian hoạt động của Bot\n"
        f"`/ad` - 🧑‍💻 Thông tin Admin\n"
        f"`/tv` - 🇻🇳 Đổi ngôn ngữ TG sang Tiếng Việt\n\n"
        f"*Lệnh SPAM:*\n"
        f"`/spam` <SĐT> <lần> - 💣 Spam SMS (Free, max {FREE_SPAM_LIMIT}, CD {FREE_SPAM_COOLDOWN}s)\n"
        f"`/smsvip` <SĐT> <lần> - 🌟 Spam SMS (VIP, max {VIP_SMS_LIMIT}, CD {VIP_SPAM_COOLDOWN}s)\n"
        f"`/spamvip` <SĐT> <lần> - 📞 Spam Call (VIP, max {VIP_CALL_LIMIT}, CD {VIP_SPAM_COOLDOWN}s)\n"
        f"`/dungspam` <SĐT> - 🛑 Dừng spam cho SĐT (VIP)\n"
    )
    if is_user_admin:
        response += (
            f"\n*Lệnh Admin:*\n"
            f"`/add` <ID> [ngày] - ✅ Thêm VIP (0=vĩnh viễn)\n"
            f"`/remove` <ID> - ❌ Xóa VIP\n"
            f"`/cleanup` - 🧹 Xóa VIP hết hạn\n"
            f"`/listvip` - 👥 Xem danh sách VIP\n"
            f"`/rs` - 🔄 Khởi động lại Bot\n"
            f"`/status` - 📊 Trạng thái hệ thống\n"
            f"`/on` / `/off` - 🟢/🔴 Bật/Tắt Bot\n"
            f"`/admod` / `/unadmod` - 🔒/🔓 Bật/Tắt chế độ Admin\n"
            f"`/freeon` / `/freeoff` - ✅/❌ Bật/Tắt lệnh `/spam`\n"
            f"`/chaton` / `/chatoff` - 💬 Bật/Tắt chế độ chat riêng\n"
            f"`/abl` <SĐT> - 🚫 Thêm SĐT vào blacklist\n"
        )
    response += f"\nTham gia nhóm chat: {CHAT_GROUP_LINK}"
    return response

@bot.message_handler(commands=['help'])
def send_help(message):
    help_text = get_help_text(message.from_user.id)
    bot.send_message(message.chat.id, help_text)
    delete_user_message(message)

# --- Spam Commands ---
def run_spam_script(message, sdt, count, script_name, log_prefix):
    """Helper function to run a spam script as a subprocess."""
    process = None
    try:
        if not os.path.isfile(script_name):
            raise FileNotFoundError(f"Script file '{script_name}' not found.")
        
        # Chạy script bằng sys.executable để đảm bảo dùng đúng môi trường python
        process = subprocess.Popen([sys.executable, script_name, sdt, str(count)])
        
        # Thêm tiến trình vào danh sách đang chạy
        if sdt in running_spams:
            running_spams[sdt].append(process)
        else:
            running_spams[sdt] = [process]
            
        logging.info(f"[{log_prefix}] Started {script_name} for {sdt} (User: {message.from_user.id}) PID: {process.pid}")
        return process, None # Success
    except Exception as e:
        logging.error(f"[{log_prefix}] Failed to start {script_name} for {sdt}: {e}", exc_info=True)
        return None, str(e) # Failure

@bot.message_handler(commands=['spam', 'smsvip'])
def unified_sms_spam(message):
    if not check_bot_status(message): return
    if not check_group_or_chat_mode(message): return

    is_vip = message.from_user.id in allowed_users
    command = message.text.split()[0].lower()

    if command == '/spam':
        if not free_spam_enabled:
            bot.reply_to(message, "❌ Lệnh `/spam` (Free) hiện đang tạm tắt.")
            delete_user_message(message)
            return
        cooldown = FREE_SPAM_COOLDOWN
        limit = FREE_SPAM_LIMIT
        log_prefix = "SPAM FREE"
    else: # /smsvip
        if not is_vip:
            bot.reply_to(message, "❌ Bạn không phải VIP hoặc VIP đã hết hạn. /mua để nâng cấp.")
            delete_user_message(message)
            return
        cooldown = VIP_SPAM_COOLDOWN
        limit = VIP_SMS_LIMIT
        log_prefix = "SMS VIP"
    
    user_id = message.from_user.id
    current_time = time.time()
    if user_id in last_usage and current_time - last_usage[user_id] < cooldown:
        wait_time = cooldown - (current_time - last_usage[user_id])
        bot.reply_to(message, f"⏳ Vui lòng đợi `{wait_time:.1f}` giây.")
        delete_user_message(message)
        return

    params = message.text.split()[1:]
    if len(params) != 2:
        bot.reply_to(message, f"⚠️ Sai cú pháp!\nVí dụ: `{command} 09xxxxxxxx {limit}`")
        delete_user_message(message)
        return
    
    sdt, count_str = params
    if not sdt.isdigit() or not (9 <= len(sdt) <= 11):
        bot.reply_to(message, "📞 Số điện thoại không hợp lệ.")
        delete_user_message(message)
        return
    if not count_str.isdigit() or not (1 <= int(count_str) <= limit):
        bot.reply_to(message, f"🔢 Số lần spam hợp lệ từ 1 đến `{limit}`.")
        delete_user_message(message)
        return
    if sdt in blacklist:
        bot.reply_to(message, f"🚫 Số điện thoại `{sdt}` đã bị chặn.")
        delete_user_message(message)
        return
    
    count = int(count_str)
    last_usage[user_id] = current_time
    
    confirmation_msg = f'''🚀 *Bắt Đầu SPAM (`{command}`)* 🚀
-----------------------------------
👤 Người gửi: {get_user_mention(message.from_user)} (`{user_id}`)
📞 Mục tiêu: `{mask_phone(sdt)}`
🔁 Số lần: `{count}`
-----------------------------------
🛠️ _Bot đang thực hiện yêu cầu..._'''
    
    msg = bot.send_message(message.chat.id, confirmation_msg)
    delete_user_message(message)

    _, error = run_spam_script(message, sdt, count, "dec.py", log_prefix)

    if error:
        final_status = f"❌ _Lỗi: Không thể chạy script.\n`{error}`_"
    else:
        final_status = "✅ _Đang chạy..._"
    
    try:
        bot.edit_message_text(confirmation_msg.replace("🛠️ _Bot đang thực hiện yêu cầu..._", final_status), msg.chat.id, msg.message_id)
    except Exception as edit_e:
        logging.warning(f"Failed to edit spam status message: {edit_e}")


@bot.message_handler(commands=['spamvip'])
def supersms_call(message):
    if not check_bot_status(message): return
    if not check_group_or_chat_mode(message): return
    
    user_id = message.from_user.id
    if user_id not in allowed_users:
        bot.reply_to(message, "❌ Bạn không phải VIP hoặc VIP đã hết hạn. /mua để nâng cấp.")
        delete_user_message(message)
        return

    current_time = time.time()
    if user_id in last_usage and current_time - last_usage[user_id] < VIP_SPAM_COOLDOWN:
        wait_time = VIP_SPAM_COOLDOWN - (current_time - last_usage[user_id])
        bot.reply_to(message, f"⏳ VIP đợi `{wait_time:.1f}` giây.")
        delete_user_message(message)
        return

    params = message.text.split()[1:]
    if len(params) != 2:
        bot.reply_to(message, f"⚠️ Sai cú pháp!\nVí dụ: `/spamvip 09xxxxxxxx {VIP_CALL_LIMIT}`")
        delete_user_message(message)
        return

    sdt, count_str = params
    if not sdt.isdigit() or not (9 <= len(sdt) <= 11):
        bot.reply_to(message, "📞 Số điện thoại không hợp lệ.")
        delete_user_message(message)
        return
    if not count_str.isdigit() or not (1 <= int(count_str) <= VIP_CALL_LIMIT):
        bot.reply_to(message, f"🔢 Số lần spam VIP Call tối đa là `{VIP_CALL_LIMIT}`.")
        delete_user_message(message)
        return
    if sdt in blacklist:
        bot.reply_to(message, f"🚫 Số điện thoại `{sdt}` đã bị chặn.")
        delete_user_message(message)
        return

    count = int(count_str)
    last_usage[user_id] = current_time
    
    confirmation_base = f'''🚀 *Bắt Đầu SPAM (`/spamvip`)* 🚀
-----------------------------------
📞 Người gửi: {get_user_mention(message.from_user)} (`{user_id}`)
📞 Mục tiêu: `{mask_phone(sdt)}`
🔁 Số lần: `{count}`
-----------------------------------'''
    
    msg = bot.send_message(message.chat.id, confirmation_base + "\n🛠️ _Bot đang thực hiện yêu cầu..._")
    delete_user_message(message)

    # Thực thi song song API và scripts
    api_status, script_dec_status, script_ii_status = "Bỏ qua", "Bỏ qua", "Bỏ qua"
    
    # 1. Gọi API
    try:
        api_url = f"https://thachmora.site/otp/?key={API_KEY_THACHMORA}&sdt={sdt}&so={count}"
        response = requests.get(api_url, timeout=20) # Thêm timeout
        response.raise_for_status()
        api_status = "Thành công ✅"
        logging.info(f"[SPAMVIP API] OK for {sdt}. Status: {response.status_code}.")
    except requests.exceptions.Timeout:
        api_status = "Thất bại (Timeout) ❌"
    except requests.exceptions.RequestException as e:
        api_status = f"Thất bại (Lỗi: {type(e).__name__}) ❌"
        logging.error(f"[SPAMVIP API] Fail for {sdt}: {e}")

    # 2. Chạy Scripts
    _, err_dec = run_spam_script(message, sdt, count, "dec.py", "SPAMVIP")
    script_dec_status = "Thành công ✅" if not err_dec else f"Thất bại ({err_dec}) ❌"
    
    _, err_ii = run_spam_script(message, sdt, count, "ii.py", "SPAMVIP")
    script_ii_status = "Thành công ✅" if not err_ii else f"Thất bại ({err_ii}) ❌"

    # Cập nhật trạng thái cuối cùng
    final_status_msg = (
        f"{confirmation_base}\n"
        f"∙ API Call: *{api_status}*\n"
        f"∙ Script `dec.py`: *{script_dec_status}*\n"
        f"∙ Script `ii.py`: *{script_ii_status}*"
    )
    
    try:
        bot.edit_message_text(final_status_msg, msg.chat.id, msg.message_id)
    except Exception as e:
        logging.warning(f"Error editing final spamvip status message: {e}")

@bot.message_handler(commands=['dungspam'])
def stop_spam(message):
    user_id = message.from_user.id
    if user_id not in allowed_users:
        bot.reply_to(message, "❌ Chỉ VIP mới có thể dừng spam.")
        delete_user_message(message)
        return

    args = message.text.split()
    if len(args) != 2 or not args[1].isdigit():
        bot.reply_to(message, "⚠️ Sai cú pháp!\nVí dụ: `/dungspam 09xxxxxxxx`")
        delete_user_message(message)
        return

    sdt_to_stop = args[1]
    if sdt_to_stop not in running_spams:
        bot.reply_to(message, f"ℹ️ Không tìm thấy tiến trình spam nào được ghi nhận cho số `{sdt_to_stop}`.")
        delete_user_message(message)
        return

    processes_to_stop = running_spams.get(sdt_to_stop, [])
    stopped_count = 0
    
    for process in processes_to_stop:
        try:
            if process.poll() is None: # Kiểm tra xem tiến trình có đang chạy không
                p = psutil.Process(process.pid)
                p.terminate() # Gửi tín hiệu dừng
                stopped_count += 1
                logging.info(f"[STOP SPAM] Terminated PID {process.pid} for {sdt_to_stop}.")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue # Bỏ qua nếu tiến trình đã chết hoặc không có quyền
        except Exception as e:
            logging.error(f"Error stopping process PID {getattr(process, 'pid', 'N/A')}: {e}", exc_info=True)

    del running_spams[sdt_to_stop] # Xóa khỏi danh sách theo dõi

    if stopped_count > 0:
        bot.reply_to(message, f"✅ Đã gửi yêu cầu dừng `{stopped_count}` tiến trình spam cho số `{sdt_to_stop}`.")
    else:
        bot.reply_to(message, f"ℹ️ Không có tiến trình spam nào *đang chạy* cho số `{sdt_to_stop}`.")
    
    delete_user_message(message)

# --- Other Utility Commands ---

@bot.message_handler(commands=['id'])
def get_user_id(message):
    response = f"👤 ID của bạn: `{message.from_user.id}`\n"
    if message.chat.type != "private":
        response += f"🏢 ID Nhóm này: `{message.chat.id}`"
    bot.reply_to(message, response)
    delete_user_message(message)

@bot.message_handler(commands=['qr'])
def generate_qr(message):
    text = message.text[len('/qr '):].strip()
    if not text:
        bot.reply_to(message, '⚠️ Cần nội dung để tạo QR.\n`/qr text here`')
        delete_user_message(message)
        return
    try:
        qr = qrcode.make(text)
        bio = io.BytesIO()
        bio.name = 'qrcode.png'
        qr.save(bio, 'PNG')
        bio.seek(0)
        bot.send_photo(message.chat.id, bio, caption=f"🖼️ QR cho:\n`{text}`")
    except Exception as e:
        bot.reply_to(message, f"❌ Lỗi tạo QR: {e}")
        logging.error(f"Error generating QR code: {e}", exc_info=True)
    delete_user_message(message)

@bot.message_handler(commands=['voice'])
def handle_voice(message):
    text = message.text[len('/voice '):].strip()
    if not text:
        bot.reply_to(message, '⚠️ Cần văn bản.\n`/voice hello world`')
        delete_user_message(message)
        return
    try:
        tts = gTTS(text=text, lang='vi')
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=True) as tmp_file:
            tts.save(tmp_file.name)
            with open(tmp_file.name, 'rb') as voice_file:
                bot.send_voice(chat_id=message.chat.id, voice=voice_file, caption=f"🗣️ Giọng nói cho:\n_{text}_")
    except Exception as e:
        bot.reply_to(message, f"❌ Lỗi tạo giọng nói: {e}")
        logging.error(f"Error in gTTS or sending voice: {e}", exc_info=True)
    delete_user_message(message)

@bot.message_handler(commands=['gg'])
def handle_gemini(message):
    if not gemini_model:
        bot.reply_to(message, "❌ Tính năng Gemini AI chưa được cấu hình.")
        delete_user_message(message)
        return
    user_input = message.text[len('/gg '):].strip()
    if not user_input:
        bot.reply_to(message, "⚠️ Cần câu hỏi cho Gemini.\n`/gg Capital of Vietnam?`")
        delete_user_message(message)
        return
    
    thinking_msg = bot.reply_to(message, "🧠 _Gemini đang suy nghĩ..._")
    try:
        response = gemini_chat_session.send_message(user_input)
        bot.edit_message_text(f"🤖 *Gemini AI:* \n\n{response.text}", thinking_msg.chat.id, thinking_msg.message_id)
    except Exception as e:
        error_message = f"❌ Lỗi khi giao tiếp với Gemini AI:\n`{e}`"
        bot.edit_message_text(error_message, thinking_msg.chat.id, thinking_msg.message_id)
        logging.error(f"Error interacting with Gemini AI: {e}", exc_info=True)
    delete_user_message(message)

@bot.message_handler(commands=['face'])
def send_random_face(message):
    url = "https://thispersondoesnotexist.com/"
    msg = bot.reply_to(message, "🧑 _Đang tải ảnh mặt người..._")
    try:
        response = requests.get(url, timeout=15) # Thêm timeout
        response.raise_for_status()
        photo = BytesIO(response.content)
        bot.delete_message(msg.chat.id, msg.message_id)
        bot.send_photo(message.chat.id, photo, caption="✨ Gương mặt này không tồn tại!")
    except requests.exceptions.RequestException as e:
         bot.edit_message_text(f"❌ Lỗi khi lấy ảnh: `{e}`", msg.chat.id, msg.message_id)
         logging.error(f"Error fetching random face: {e}", exc_info=True)
    delete_user_message(message)

@bot.message_handler(commands=['tiktok'])
def tiktok_command(message):
    url = message.text[len('/tiktok '):].strip()
    if not url:
        bot.reply_to(message, "⚠️ Cần link TikTok.\n`/tiktok <link>`")
        delete_user_message(message)
        return
        
    wait_msg = bot.reply_to(message, "⏳ _Đang lấy thông tin TikTok..._")
    api_url = f'https://tikwm.com/api/?url={url}'
    
    try:
        response = requests.get(api_url, timeout=20) # Thêm timeout
        response.raise_for_status()
        data = response.json()
        
        if data.get('code') == 0 and 'data' in data:
            info = data['data']
            video_url = info.get('play') or info.get('wmplay')
            music_url = info.get('music_info', {}).get('play')
            
            caption = f"🎬 *Tiêu đề:* {info.get('title', 'N/A')}"
            markup = InlineKeyboardMarkup()
            buttons = []
            if video_url: buttons.append(InlineKeyboardButton("🎬 Video", url=video_url))
            if music_url: buttons.append(InlineKeyboardButton("🎶 Audio", url=music_url))
            if buttons: markup.add(*buttons)
            
            bot.edit_message_text(caption, wait_msg.chat.id, wait_msg.message_id, reply_markup=markup, disable_web_page_preview=True)
        else:
            bot.edit_message_text(f"❌ Lỗi lấy dữ liệu TikTok: `{data.get('msg', 'Lỗi không xác định')}`", wait_msg.chat.id, wait_msg.message_id)
    except Exception as e:
        bot.edit_message_text(f"❌ Lỗi khi xử lý yêu cầu TikTok: `{e}`", wait_msg.chat.id, wait_msg.message_id)
        logging.error(f"Error in /tiktok: {e}", exc_info=True)
    delete_user_message(message)

@bot.message_handler(commands=['tool', 'tv', 'ad'])
def simple_commands(message):
    command = message.text.split()[0].lower()
    if command == '/tool':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton(text="🛠️ Tool LeQuocKhang", url="https://lequockhang.site/tool.html"))
        bot.reply_to(message, "🔗 Các liên kết công cụ:", reply_markup=markup)
    elif command == '/tv':
        keyboard = types.InlineKeyboardMarkup()
        url_button = types.InlineKeyboardButton("🇻🇳 Đặt Tiếng Việt 🇻🇳", url='https://t.me/setlanguage/vi-beta')
        keyboard.add(url_button)
        bot.send_message(message.chat.id, 'Nhấn nút bên dưới để đổi ngôn ngữ Telegram sang Tiếng Việt:', reply_markup=keyboard)
    elif command == '/ad':
        bot.reply_to(message, f"👑 *Admin:* @{ADMIN_USERNAME}\n🆔 *ID:* `{ADMIN_ID}`")
    delete_user_message(message)

# --- VIP Purchase and Management ---
@bot.message_handler(commands=['mua'])
def mua_command(message, from_callback=False, callback_user=None):
    user = callback_user if from_callback else message.from_user
    response_message = (
        f"💰 *Yêu Cầu Mua VIP*\n\n"
        f"👤 Người dùng: {get_user_mention(user)} (`{user.id}`)\n"
        f"✨ Gói VIP: *{VIP_PRICE} / {VIP_DURATION_DAYS} ngày*\n\n"
        f"*Thông Tin Thanh Toán:*\n"
        f"🏦 Ngân hàng: *VIETCOMBANK*\n"
        f"💳 STK: `1049565152`\n"
        f"👤 Tên TK: LE QUOC KHANG\n"
        f"📝 Nội dung CK: `{user.id}` (*BẮT BUỘC*)\n\n"
        f"👉 Sau khi CK, nhấn *'Gửi Ảnh CK'* và gửi ảnh chụp màn hình giao dịch thành công."
    )
    users_requested_payment[user.id] = True
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(
        InlineKeyboardButton("📸 Gửi Ảnh CK", url=f"https://t.me/{BOT_USERNAME}?start=send_payment"),
        InlineKeyboardButton("🧑‍💻 Liên Hệ Admin", url=f"https://t.me/{ADMIN_USERNAME}")
    )
    try:
        bot.send_photo(message.chat.id, photo=PAYMENT_IMAGE_URL, caption=response_message, reply_markup=markup)
    except Exception as e:
        bot.send_message(message.chat.id, response_message, reply_markup=markup, disable_web_page_preview=True)
        logging.error(f"Error sending payment info photo: {e}", exc_info=True)
    if not from_callback:
        delete_user_message(message)

@bot.message_handler(content_types=['photo'])
def handle_payment_photo(message):
    user_id = message.from_user.id
    if users_requested_payment.get(user_id):
        user_info = get_user_mention(message.from_user)
        admin_caption = f"📸 Ảnh thanh toán VIP từ:\n👤 {user_info}\n🆔 `{user_id}`\n\n👉 Kiểm tra và dùng lệnh:\n`/add {user_id}`"
        try:
            bot.send_photo(chat_id=ADMIN_ID, photo=message.photo[-1].file_id, caption=admin_caption)
            bot.reply_to(message, "✅ Đã nhận được ảnh thanh toán. Admin sẽ kiểm tra và kích hoạt VIP sớm!")
            logging.info(f"[PAYMENT] Received payment photo from {user_id}. Forwarded to Admin.")
            del users_requested_payment[user_id]
        except Exception as e:
            bot.reply_to(message, f"❌ Lỗi gửi ảnh đến Admin. Vui lòng liên hệ Admin trực tiếp qua @{ADMIN_USERNAME} và gửi ảnh này nhé.")
            logging.error(f"Error forwarding payment photo from {user_id} to Admin {ADMIN_ID}: {e}", exc_info=True)

# --- Admin Commands ---

def admin_only(func):
    """Decorator to check for admin privileges."""
    def wrapped(message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, '❌ Bạn không có quyền.')
            delete_user_message(message)
            return
        return func(message)
    return wrapped

@bot.message_handler(commands=['add'])
@admin_only
def add_user(message):
    args = message.text.split()
    if not (2 <= len(args) <= 3):
        bot.reply_to(message, f'⚠️ Sai cú pháp!\n`/add <ID> [số ngày]`\n(Mặc định {VIP_DURATION_DAYS} ngày, 0 = Vĩnh viễn)')
        return delete_user_message(message)
    try:
        user_id_to_add = int(args[1])
        days = VIP_DURATION_DAYS
        if len(args) == 3:
            days = int(args[2])
        
        expiration_time = None
        expiration_text = "Vĩnh Viễn"
        if days > 0:
            expiration_time = datetime.now() + timedelta(days=days)
            expiration_text = f"{days} ngày"
        
        username_to_add = None
        try:
            username_to_add = bot.get_chat(user_id_to_add).username
        except Exception:
            pass # Bỏ qua nếu không lấy được username

        save_user_to_database(user_id_to_add, expiration_time, username_to_add)
        
        expiry_info = expiration_time.strftime('%d/%m/%Y %H:%M:%S') if expiration_time else "Vĩnh viễn"
        confirmation_group = (f"✅ Đã thêm VIP thành công!\n"
                              f"👤 Người dùng: ID `{user_id_to_add}`\n"
                              f"⏳ Thời hạn: *{expiration_text}*\n"
                              f"📅 Hết hạn: `{expiry_info}`")
        bot.reply_to(message, confirmation_group)
        
        try:
            confirmation_user = (f"🎉 Chúc mừng! Bạn đã được cấp quyền *VIP*.\n"
                                 f"⏳ Thời hạn: *{expiration_text}*\n"
                                 f"📅 Hết hạn: `{expiry_info}`")
            bot.send_message(user_id_to_add, confirmation_user)
        except Exception as e:
            logging.warning(f"Could not send private notification to {user_id_to_add}: {e}")

    except (ValueError, IndexError):
        bot.reply_to(message, '❌ ID hoặc số ngày không hợp lệ.')
    delete_user_message(message)

@bot.message_handler(commands=['remove'])
@admin_only
def remove_user_cmd(message):
    try:
        user_id_to_remove = int(message.text.split()[1])
        remove_user_from_database(user_id_to_remove)
        bot.reply_to(message, f'✅ Đã xóa người dùng VIP có ID `{user_id_to_remove}`.')
        logging.info(f"[ADMIN] Removed VIP User {user_id_to_remove} by Admin {message.from_user.id}")
    except (ValueError, IndexError):
        bot.reply_to(message, '⚠️ Sai cú pháp!\n`/remove <ID người dùng>`')
    delete_user_message(message)

@bot.message_handler(commands=['cleanup'])
@admin_only
def cleanup_expired_users_cmd(message):
    deleted_count = delete_expired_users_from_db()
    if deleted_count > 0:
        bot.reply_to(message, f'🧹 Đã xóa `{deleted_count}` VIP hết hạn khỏi database.')
    else:
        bot.reply_to(message, '🧹 Không có VIP nào hết hạn để xóa.')
    delete_user_message(message)

@bot.message_handler(commands=['listvip'])
@admin_only
def list_vip_users_command(message):
    # This function uses the improved logic from your provided code
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT user_id, username, expiration_time FROM users ORDER BY user_id')
            all_vips = cursor.fetchall()

        if not all_vips:
            bot.reply_to(message, "ℹ️ Hiện không có thành viên VIP nào.")
            return

        response_text = f"<b>📜 Danh Sách VIP ({len(all_vips)}) 📜</b>\n--------------------\n"
        now = datetime.now()
        
        for user_id, username, expiration_time_str in all_vips:
            user_display = f"@{username}" if username else f"User_{user_id}"
            expiry_info = "✨ <b>Vĩnh viễn</b>"
            
            if expiration_time_str:
                try:
                    expiry_dt = datetime.strptime(expiration_time_str, '%Y-%m-%d %H:%M:%S')
                    if expiry_dt > now:
                        remaining = expiry_dt - now
                        expiry_info = f"⏳ Hết hạn: {expiry_dt.strftime('%d/%m/%Y')} (~{format_timedelta(remaining)} còn lại)"
                    else:
                        expiry_info = f"❌ Đã hết hạn: {expiry_dt.strftime('%d/%m/%Y')}"
                except ValueError:
                    expiry_info = f"⚠️ Lỗi định dạng ngày"

            response_text += f"👤 <code>{user_id}</code> ({user_display})\n   {expiry_info}\n--------------------\n"

        # Tách tin nhắn nếu quá dài
        for part in telebot.util.smart_split(response_text, 4000):
            bot.send_message(message.chat.id, part, parse_mode='HTML')
            time.sleep(0.3)

    except Exception as e:
        bot.reply_to(message, f"❌ Lỗi khi hiển thị danh sách VIP: {e}")
        logging.error(f"Error in /listvip handler: {e}", exc_info=True)
    delete_user_message(message)

@bot.message_handler(commands=['plan'])
def check_vip_plan(message):
    user_id = message.from_user.id
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT expiration_time FROM users WHERE user_id = ?", (user_id,))
            result = cursor.fetchone()

        if result:
            expiration_time_str = result[0]
            if expiration_time_str is None:
                response_message = f"✨ {get_user_mention(message.from_user)}, bạn là *VIP Vĩnh Viễn*!"
            else:
                expiry_dt = datetime.strptime(expiration_time_str, '%Y-%m-%d %H:%M:%S')
                if expiry_dt >= datetime.now():
                    response_message = (f"✅ {get_user_mention(message.from_user)}, bạn là *VIP*.\n"
                                       f"📅 Hết hạn vào: `{expiry_dt.strftime('%d/%m/%Y %H:%M:%S')}`\n"
                                       f"⏳ Còn lại: *{format_timedelta(expiry_dt - datetime.now())}*")
                else:
                    response_message = f"⚠️ {get_user_mention(message.from_user)}, VIP của bạn đã *hết hạn*.\n👉 /mua để gia hạn."
        else:
            response_message = f"❌ {get_user_mention(message.from_user)}, bạn *chưa phải* là VIP.\n👉 /mua để nâng cấp."

        bot.reply_to(message, response_message)
    except Exception as e:
        bot.reply_to(message, "❌ Lỗi khi kiểm tra VIP.")
        logging.error(f"Database error in /plan for user {user_id}: {e}", exc_info=True)
    delete_user_message(message)


@bot.message_handler(commands=['rs'])
@admin_only
def handle_reset(message):
    bot.reply_to(message, "🔄 *Đang khởi động lại Bot...*")
    logging.info(f"[ADMIN] Restart command issued by Admin {message.from_user.id}")
    
    # Dừng các tiến trình spam đang chạy
    logging.info("[RESTART] Stopping all running spam processes...")
    for sdt, process_list in list(running_spams.items()):
        for process in process_list:
            try:
                if process.poll() is None:
                    p = psutil.Process(process.pid)
                    p.kill() # Kill dứt khoát
                    logging.info(f"[RESTART] Killed PID {p.pid} for {sdt}.")
            except Exception as e:
                logging.warning(f"[RESTART] Could not kill process {getattr(process, 'pid', 'N/A')}: {e}")
    running_spams.clear()
    
    time.sleep(2)
    bot.stop_polling()
    logging.info("[RESTART] Executing restart...")
    os.execl(sys.executable, sys.executable, *sys.argv)

@bot.message_handler(commands=['status'])
@admin_only
def status(message):
    try:
        uname = platform.uname()
        cpu_usage = psutil.cpu_percent(interval=0.5)
        memory_info = psutil.virtual_memory()
        disk_info = psutil.disk_usage('/')
        uptime_seconds = int(time.time() - start_time)
        uptime_str = str(timedelta(seconds=uptime_seconds))

        running_process_count = sum(1 for proc_list in running_spams.values() for proc in proc_list if proc.poll() is None)

        status_message = (
            f"📊 *Trạng Thái Hệ Thống & Bot*\n\n"
            f"*Bot:*\n"
            f"- Status: {'🟢 Hoạt động' if bot_active else '🔴 Tạm dừng'}\n"
            f"- Admin Mode: {'🔒 Bật' if admin_mode else '🔓 Tắt'}\n"
            f"- VIP hoạt động: `{len(allowed_users)}`\n"
            f"- Tiến trình Spam: `{running_process_count}`\n"
            f"- Uptime: `{uptime_str}`\n\n"
            f"*Server:*\n"
            f"- OS: `{uname.system} {uname.release}`\n"
            f"- CPU: `{cpu_usage:.1f}%`\n"
            f"- RAM: `{memory_info.percent:.1f}%` (`{memory_info.available / (1024 ** 3):.2f}` GB free)\n"
            f"- Disk: `{disk_info.percent:.1f}%` (`{disk_info.free / (1024 ** 3):.2f}` GB free)"
        )
        bot.reply_to(message, status_message)
    except Exception as e:
        bot.reply_to(message, f"❌ Lỗi lấy trạng thái: {e}")
        logging.error(f"Error getting status: {e}", exc_info=True)
    delete_user_message(message)

# --- Toggle Commands ---
@bot.message_handler(commands=['on', 'off', 'admod', 'unadmod', 'freeon', 'freeoff', 'chaton', 'chatoff'])
@admin_only
def toggle_commands(message):
    global bot_active, admin_mode, free_spam_enabled, private_chat_enabled
    cmd = message.text.split()[0].lower()
    
    actions = {
        '/on': ('bot_active', True, '🟢 Bot đã *bật*.'),
        '/off': ('bot_active', False, '🔴 Bot đã *tắt*.'),
        '/admod': ('admin_mode', True, '🔒 Chế độ Admin *bật*.'),
        '/unadmod': ('admin_mode', False, '🔓 Chế độ Admin *tắt*.'),
        '/freeon': ('free_spam_enabled', True, '✅ Lệnh `/spam` (Free) đã *bật*.'),
        '/freeoff': ('free_spam_enabled', False, '❌ Lệnh `/spam` (Free) đã *tắt*.'),
        '/chaton': ('private_chat_enabled', True, '💬 Chế độ chat riêng *bật*.'),
        '/chatoff': ('private_chat_enabled', False, '🏢 Chế độ chat riêng *tắt*.'),
    }
    
    if cmd in actions:
        var_name, value, reply_text = actions[cmd]
        globals()[var_name] = value
        bot.reply_to(message, reply_text)
        logging.info(f"[ADMIN] Toggled {var_name} to {value} by {message.from_user.id}")
    
    delete_user_message(message)

@bot.message_handler(commands=['abl'])
@admin_only
def add_to_blacklist(message):
    try:
        phone_number = message.text.split()[1]
        if not phone_number.isdigit(): raise ValueError("Not a digit")
        if phone_number in blacklist:
            bot.reply_to(message, f"ℹ️ Số `{phone_number}` đã có trong blacklist.")
        else:
            blacklist.add(phone_number)
            bot.reply_to(message, f"🚫 Đã thêm `{phone_number}` vào blacklist.")
            logging.info(f"[ADMIN] Added {phone_number} to blacklist by {message.from_user.id}")
    except (IndexError, ValueError):
        bot.reply_to(message, "⚠️ Sai cú pháp!\nVí dụ: `/abl 09xxxxxxxx`")
    delete_user_message(message)


# --- Main Execution ---
if __name__ == "__main__":
    logging.info("-" * 30)
    logging.info("Initializing Database...")
    init_db()
    logging.info("Cleaning up expired VIP users on start...")
    delete_expired_users_from_db()
    logging.info("Loading VIP Users...")
    load_users_from_database()
    logging.info("-" * 30)
    logging.info(f"Bot Admin ID: {ADMIN_ID}")
    logging.info(f"Bot Username: @{BOT_USERNAME}")
    logging.info(f"Bot starting at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logging.info("-" * 30)

    # Vòng lặp chạy bot mạnh mẽ, tự động kết nối lại
    while True:
        try:
            logging.info("Bot is connected and polling...")
            bot.infinity_polling(timeout=60, long_polling_timeout=60)
        except requests.exceptions.ReadTimeout as e:
            logging.warning(f"Polling ReadTimeout: {e}. Reconnecting in 5 seconds...")
            time.sleep(5)
        except requests.exceptions.ConnectionError as e:
            logging.warning(f"Polling ConnectionError: {e}. Retrying in 15 seconds...")
            time.sleep(15)
        except telebot.apihelper.ApiTelegramException as e:
            logging.error(f"Telegram API Exception: {e}. Retrying...", exc_info=True)
            if 'Conflict: terminated by other getUpdates request' in str(e):
                logging.warning("Polling conflict detected. Waiting 30s before retrying...")
                time.sleep(30)
            else:
                time.sleep(10)
        except Exception as e:
            logging.critical(f"An unexpected critical error occurred in the polling loop: {e}", exc_info=True)
            traceback.print_exc()
            logging.info("Restarting polling in 30 seconds...")
            time.sleep(30)

